<#
.SYNOPSIS
    Home Lab Setup - Main Entry Point
.DESCRIPTION
    This script serves as the main entry point for the Home Lab Setup project,
    providing a menu-driven interface to access all functionality.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Get script path
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$modulePath = Join-Path -Path $scriptPath -ChildPath "modules\HomeLab"

# Import the module
Import-Module $modulePath -Force

# Check prerequisites
if (-not (Test-Prerequisites)) {
    Write-Host "Installing missing prerequisites..." -ForegroundColor Yellow
    Install-Prerequisites
    
    if (-not (Test-Prerequisites)) {
        Write-Host "Prerequisites installation failed. Please check the logs and try again." -ForegroundColor Red
        exit 1
    }
}

# Run first-time setup if needed
if (-not (Test-SetupComplete)) {
    Write-Host "Running first-time setup..." -ForegroundColor Yellow
    Initialize-HomeLab
}

# Start the application
Start-HomeLab
