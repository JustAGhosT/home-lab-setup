# deploy.ps1
# Main deployment script that orchestrates the entire process

param(
    [string]$ENV = "dev",
    [string]$LOC = "saf",
    [string]$PROJECT = "homelab",
    [string]$LOCATION = "southafricanorth",
    [string]$LogFile = "AzureDeployment_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
)

# Import helper modules
. .\modules\Logging.ps1
. .\modules\AzurePrerequisites.ps1
. .\modules\ResourceManagement.ps1
. .\modules\DeploymentTools.ps1
. .\modules\VpnManagement.ps1

# Initialize log file
Initialize-LogFile -LogFilePath $LogFile

# Display header
Write-Log "+----------------------------------------+" -Color "Blue"
Write-Log "|       AZURE HOME LAB DEPLOYMENT TOOL   |" -Color "Blue"
Write-Log "+----------------------------------------+" -Color "Blue"
Write-Log "Starting deployment process..." -Color "Cyan"

# Resource group name
$RESOURCE_GROUP = "$ENV-$LOC-rg-$PROJECT"
$GATEWAY_NAME = "$ENV-$LOC-vpng-$PROJECT"

try {
    # Check Azure CLI and login
    Write-Log ">> Checking for Azure CLI..." -Color "White"
    $cliReady = Test-AzureCliPrerequisites
    if (-not $cliReady) {
        Write-Log "Azure CLI prerequisites not met. Exiting script." -Color "Red"
        exit 1
    }

    # Check Azure login
    Write-Log ">> Checking Azure login status..." -Color "White"
    $loggedIn = Connect-AzureAccount
    if (-not $loggedIn) {
        Write-Log "Azure login is required to continue. Exiting script." -Color "Red"
        exit 1
    }

    # Check and prepare resource group
    $rgExists = Test-ResourceGroup -ResourceGroupName $RESOURCE_GROUP
    if ($rgExists) {
        $resetRg = Reset-ResourceGroup -ResourceGroupName $RESOURCE_GROUP
        if (-not $resetRg -and (Get-UserConfirmation -Message "Do you want to continue with the existing resource group?") -eq $false) {
            Write-Log "Deployment cancelled by user." -Color "Yellow"
            exit 0
        }
    } else {
        $created = New-AzureResourceGroup -ResourceGroupName $RESOURCE_GROUP -Location $LOCATION
        if (-not $created) {
            Write-Log "Failed to create resource group. Exiting script." -Color "Red"
            exit 1
        }
    }

    # Deploy infrastructure
    Write-Log ">> Starting infrastructure deployment..." -Color "White"
    Write-Log "This may take 15-20 minutes to complete. Please be patient." -Color "Yellow"

    # Generate a unique deployment name
    $deploymentName = "deploy-$(Get-Date -Format 'yyyyMMddHHmmss')"

    # Start the deployment
    $parameters = @{
        "env" = $ENV
        "loc" = $LOC
        "project" = $PROJECT
        "location" = $LOCATION
    }

    $deploymentSuccess = Deploy-BicepTemplate -DeploymentName $deploymentName -Location $LOCATION -TemplateFile "main.bicep" -Parameters $parameters

    if (-not $deploymentSuccess) {
        Write-Log "Deployment failed. Check the logs for details." -Color "Red"
        exit 1
    }

    # Wait for VPN Gateway to be fully provisioned
    $gatewayReady = Wait-VpnGatewayProvisioning -ResourceGroupName $RESOURCE_GROUP -GatewayName $GATEWAY_NAME

    # Generate and download VPN client configuration
    if ($gatewayReady) {
        $vpnConfigPath = Join-Path -Path $PWD -ChildPath "vpnclientconfiguration.zip"
        $vpnConfigSuccess = Get-VpnClientConfiguration -ResourceGroupName $RESOURCE_GROUP -GatewayName $GATEWAY_NAME -OutputPath $vpnConfigPath
        
        if (-not $vpnConfigSuccess) {
            Write-Log "Failed to generate VPN client configuration. Check the logs for details." -Color "Yellow"
        }
    }

    # Display summary
    Show-DeploymentSummary -ResourceGroup $RESOURCE_GROUP -GatewayName $GATEWAY_NAME -Location $LOCATION -Environment $ENV -VpnConfigPath $vpnConfigPath -LogFilePath $LogFile
}
catch {
    Write-Log "An error occurred during deployment: $_" -Color "Red"
    Write-Log $_.Exception.StackTrace -Color "Red"
    exit 1
}
