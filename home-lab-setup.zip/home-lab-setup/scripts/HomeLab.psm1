<#
.SYNOPSIS
    HomeLab PowerShell Module
.DESCRIPTION
    Provides functions for deploying and managing a home lab environment in Azure
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Import all function scripts
$scriptPath = Split-Path -Parent $PSCommandPath
$functionFiles = Get-ChildItem -Path "$scriptPath\functions" -Filter "*.ps1" -ErrorAction SilentlyContinue

if ($functionFiles) {
    foreach ($file in $functionFiles) {
        try {
            . $file.FullName
            Write-Verbose "Imported function file: $($file.FullName)"
        } catch {
            Write-Error "Failed to import function file $($file.FullName): $_"
        }
    }
}

# Export public functions
Export-ModuleMember -Function @(
    'Deploy-Infrastructure',
    'Invoke-DeployMenu',
    'Show-DeployMenu',
    'Get-Configuration',
    'Test-Prerequisites',
    'Install-Prerequisites',
    'Test-SetupComplete',
    'Initialize-HomeLab',
    'Start-HomeLab',
    'Write-Log'
)
