<#
.SYNOPSIS
    Logging functionality for HomeLab setup
.DESCRIPTION
    This module provides logging functionality for the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Module variables
$script:logFile = $null
$script:logInitialized = $false

<#
.SYNOPSIS
    Initializes the log file
.DESCRIPTION
    Creates and initializes the log file for the HomeLab setup
.PARAMETER LogFilePath
    The path to the log file
.EXAMPLE
    Initialize-LogFile -LogFilePath "C:\Logs\HomeLab.log"
#>
function Initialize-LogFile {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$LogFilePath
    )
    
    try {
        # Create directory if it doesn't exist
        $logDir = Split-Path -Parent $LogFilePath
        if (-not (Test-Path -Path $logDir)) {
            New-Item -Path $logDir -ItemType Directory -Force | Out-Null
        }
        
        # Set the log file path
        $script:logFile = $LogFilePath
        
        # Write initial log entry
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $message = "Log initialized at $timestamp"
        Add-Content -Path $script:logFile -Value $message
        
        $script:logInitialized = $true
        
        Write-Host "Logging initialized. Log file: $LogFilePath" -ForegroundColor Green
    }
    catch {
        Write-Host "Error initializing log file: $_" -ForegroundColor Red
        $script:logInitialized = $false
    }
}

<#
.SYNOPSIS
    Writes a log entry
.DESCRIPTION
    Writes a log entry to the log file with timestamp and severity
.PARAMETER Message
    The message to log
.PARAMETER Severity
    The severity of the log entry (Information, Warning, Error)
.EXAMPLE
    Write-Log -Message "Operation completed successfully" -Severity Information
#>
function Write-Log {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("Information", "Warning", "Error")]
        [string]$Severity = "Information"
    )
    
    if (-not $script:logInitialized) {
        Write-Host "Log file not initialized. Call Initialize-LogFile first." -ForegroundColor Red
        return
    }
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Severity] $Message"
    
    try {
        Add-Content -Path $script:logFile -Value $logEntry
        
        # Also write to console with appropriate color
        switch ($Severity) {
            "Information" { Write-Host $logEntry -ForegroundColor White }
            "Warning" { Write-Host $logEntry -ForegroundColor Yellow }
            "Error" { Write-Host $logEntry -ForegroundColor Red }
        }
    }
    catch {
        Write-Host "Error writing to log file: $_" -ForegroundColor Red
    }
}

<#
.SYNOPSIS
    Gets the current log file path
.DESCRIPTION
    Returns the path to the current log file
.EXAMPLE
    $logPath = Get-LogFilePath
.OUTPUTS
    System.String. The path to the current log file.
#>
function Get-LogFilePath {
    [CmdletBinding()]
    [OutputType([string])]
    param()
    
    return $script:logFile
}

# Export functions


