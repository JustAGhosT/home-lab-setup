<#
.SYNOPSIS
    Checks and installs prerequisites for the HomeLab environment.
.DESCRIPTION
    This module contains functions to check for and install required prerequisites
    for the HomeLab environment, including Azure CLI, PowerShell modules, and permissions.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Module variables
$requiredModules = @(
    @{Name = "Az"; MinVersion = "9.0.0"},
    @{Name = "Az.Network"; MinVersion = "5.0.0"}
)

<#
.SYNOPSIS
    Tests if all prerequisites are installed and configured.
.DESCRIPTION
    Checks if Azure CLI is installed, required PowerShell modules are available,
    and if the user is logged into Azure with appropriate permissions.
.EXAMPLE
    if (Test-Prerequisites) { Write-Host "All prerequisites are installed!" }
.OUTPUTS
    Boolean. Returns $true if all prerequisites are met, $false otherwise.
#>
function Test-Prerequisites {
    [CmdletBinding()]
    [OutputType([bool])]
    param()

    $allPrerequisitesMet = $true
    
    # Check if Azure CLI is installed
    if (-not (Test-AzureCli)) {
        Write-Host "Azure CLI is not installed." -ForegroundColor Yellow
        $allPrerequisitesMet = $false
    }
    
    # Check if required PowerShell modules are installed
    foreach ($module in $requiredModules) {
        if (-not (Test-PowerShellModule -ModuleName $module.Name -MinVersion $module.MinVersion)) {
            Write-Host "PowerShell module $($module.Name) version $($module.MinVersion) or higher is not installed." -ForegroundColor Yellow
            $allPrerequisitesMet = $false
        }
    }
    
    # Check if logged into Azure
    if (-not (Test-AzureLogin)) {
        Write-Host "Not logged into Azure." -ForegroundColor Yellow
        $allPrerequisitesMet = $false
    }
    
    return $allPrerequisitesMet
}

<#
.SYNOPSIS
    Installs missing prerequisites.
.DESCRIPTION
    Attempts to install any missing prerequisites, including Azure CLI and PowerShell modules.
.EXAMPLE
    Install-Prerequisites
#>
function Install-Prerequisites {
    [CmdletBinding()]
    param()
    
    $installSuccess = $true
    
    # Install Azure CLI if missing
    if (-not (Test-AzureCli)) {
        Write-Host "Installing Azure CLI..." -ForegroundColor Cyan
        try {
            # For Windows
            if ($IsWindows -or (!$IsLinux -and !$IsMacOS)) {
                Write-Host "Downloading Azure CLI installer..." -ForegroundColor Cyan
                $tempFile = [System.IO.Path]::GetTempFileName() + ".msi"
                Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile $tempFile
                
                Write-Host "Running Azure CLI installer (this may take a few minutes)..." -ForegroundColor Cyan
                $process = Start-Process msiexec.exe -ArgumentList "/I `"$tempFile`" /quiet" -Wait -PassThru
                
                if ($process.ExitCode -eq 0) {
                    Write-Host "Azure CLI installation completed. You may need to restart your PowerShell session." -ForegroundColor Green
                    # Refresh PATH environment variable
                    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
                } else {
                    Write-Host "Azure CLI installation failed with exit code: $($process.ExitCode)" -ForegroundColor Red
                    $installSuccess = $false
                }
                
                Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
            }
            # For Linux
            elseif ($IsLinux) {
                Write-Host "Please install Azure CLI manually on Linux using the following command:" -ForegroundColor Yellow
                Write-Host "curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash" -ForegroundColor Cyan
                $installSuccess = $false
            }
            # For macOS
            elseif ($IsMacOS) {
                Write-Host "Please install Azure CLI manually on macOS using the following command:" -ForegroundColor Yellow
                Write-Host "brew update && brew install azure-cli" -ForegroundColor Cyan
                $installSuccess = $false
            }
        }
        catch {
            Write-Error "Failed to install Azure CLI: $_"
            $installSuccess = $false
        }
    }
    
    # Install required PowerShell modules if missing
    foreach ($module in $requiredModules) {
        if (-not (Test-PowerShellModule -ModuleName $module.Name -MinVersion $module.MinVersion)) {
            Write-Host "Installing PowerShell module $($module.Name)..." -ForegroundColor Cyan
            try {
                Install-Module -Name $module.Name -Force -AllowClobber -Scope CurrentUser -MinimumVersion $module.MinVersion
                
                # Verify installation
                if (Test-PowerShellModule -ModuleName $module.Name -MinVersion $module.MinVersion) {
                    Write-Host "Successfully installed $($module.Name) module." -ForegroundColor Green
                } else {
                    Write-Host "Failed to install $($module.Name) module." -ForegroundColor Red
                    $installSuccess = $false
                }
            }
            catch {
                Write-Error "Failed to install module $($module.Name): $_"
                $installSuccess = $false
            }
        }
    }
    
    # Prompt for Azure login if not logged in
    if (-not (Test-AzureLogin)) {
        Write-Host "Please log in to Azure..." -ForegroundColor Cyan
        try {
            Connect-AzAccount
            
            # Verify login
            if (Test-AzureLogin) {
                Write-Host "Successfully logged in to Azure." -ForegroundColor Green
                
                # Display available subscriptions
                $subscriptions = Get-AzSubscription
                Write-Host "Available subscriptions:" -ForegroundColor Cyan
                $subscriptions | Format-Table Name, Id -AutoSize
                
                # If multiple subscriptions, prompt to select one
                if ($subscriptions.Count -gt 1) {
                    Write-Host "Multiple subscriptions found. Please select the subscription you want to use:" -ForegroundColor Yellow
                    $selectedSubscription = $subscriptions | Out-GridView -Title "Select a subscription" -PassThru
                    if ($selectedSubscription) {
                        Set-AzContext -SubscriptionId $selectedSubscription.Id
                        Write-Host "Selected subscription: $($selectedSubscription.Name)" -ForegroundColor Green
                    }
                }
            } else {
                Write-Host "Failed to log in to Azure." -ForegroundColor Red
                $installSuccess = $false
            }
        }
        catch {
            Write-Error "Failed to log in to Azure: $_"
            $installSuccess = $false
        }
    }
    
    return $installSuccess
}


<#
.SYNOPSIS
    Tests if Azure CLI is installed.
.DESCRIPTION
    Checks if the Azure CLI is installed and available in the system path.
.OUTPUTS
    Boolean. Returns $true if Azure CLI is installed, $false otherwise.
#>
function Test-AzureCli {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    
    Write-Verbose "Testing for Azure CLI installation..."
    
    # Method 1: Try direct command execution
    try {
        $azVersion = & az --version 2>$null
        if ($null -ne $azVersion -and $azVersion -match "azure-cli") {
            Write-Verbose "Azure CLI detected via direct execution"
            return $true
        }
    }
    catch {
        Write-Verbose "Direct execution check failed: $_"
        # Continue to next method
    }
    
    # Method 2: Check common installation paths
    $commonPaths = @(
        "C:\Program Files (x86)\Microsoft SDKs\Azure\CLI2\wbin\az.cmd",
        "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd",
        "$env:LOCALAPPDATA\Programs\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"
    )
    
    foreach ($path in $commonPaths) {
        if (Test-Path -Path $path) {
            Write-Verbose "Azure CLI found at: $path"
            
            # Temporarily add to PATH for this session if not already in PATH
            $pathDir = Split-Path -Parent $path
            if ($env:Path -notlike "*$pathDir*") {
                Write-Verbose "Adding Azure CLI directory to PATH for this session"
                $env:Path += ";$pathDir"
            }
            
            return $true
        }
    }
    
    # Method 3: Try Get-Command (which searches PATH)
    try {
        $azPath = Get-Command az -ErrorAction SilentlyContinue
        if ($null -ne $azPath) {
            Write-Verbose "Azure CLI found at: $($azPath.Source)"
            return $true
        }
    }
    catch {
        Write-Verbose "Get-Command check failed: $_"
        # Continue to next method
    }
    
    # Method 4: Look for Python installation with azure-cli package
    try {
        $pythonPaths = @(
            "C:\Program Files\Python*\python.exe",
            "C:\Program Files (x86)\Python*\python.exe",
            "$env:LOCALAPPDATA\Programs\Python\Python*\python.exe"
        )
        
        foreach ($pythonPath in $pythonPaths) {
            $pythonExes = Get-Item -Path $pythonPath -ErrorAction SilentlyContinue
            foreach ($python in $pythonExes) {
                $pipList = & $python.FullName -m pip list 2>$null
                if ($pipList -match "azure-cli") {
                    Write-Verbose "Azure CLI found installed via Python at: $($python.FullName)"
                    return $true
                }
            }
        }
    }
    catch {
        Write-Verbose "Python check failed: $_"
        # Continue to final check
    }
    
    # Method 5: Check if az.cmd exists in any directory in PATH
    try {
        foreach ($pathDir in $env:Path.Split(';')) {
            if ([string]::IsNullOrWhiteSpace($pathDir)) { continue }
            
            $potentialAzPath = Join-Path -Path $pathDir -ChildPath "az.cmd"
            if (Test-Path -Path $potentialAzPath) {
                Write-Verbose "Azure CLI found at: $potentialAzPath"
                return $true
            }
        }
    }
    catch {
        Write-Verbose "PATH scan failed: $_"
    }
    
    Write-Verbose "Azure CLI not found after all detection methods"
    return $false
}

<#
.SYNOPSIS
    Tests if a PowerShell module is installed.
.DESCRIPTION
    Checks if a specific PowerShell module is installed with the required minimum version.
.PARAMETER ModuleName
    The name of the module to check.
.PARAMETER MinVersion
    The minimum version required.
.OUTPUTS
    Boolean. Returns $true if the module is installed with the required version, $false otherwise.
#>
function Test-PowerShellModule {
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ModuleName,
        
        [Parameter(Mandatory = $false)]
        [string]$MinVersion = "0.0.0"
    )
    
    $module = Get-Module -Name $ModuleName -ListAvailable | Sort-Object -Property Version -Descending | Select-Object -First 1
    
    if ($null -eq $module) {
        return $false
    }
    
    if ([version]$module.Version -lt [version]$MinVersion) {
        return $false
    }
    
    return $true
}

<#
.SYNOPSIS
    Tests if the user is logged into Azure.
.DESCRIPTION
    Checks if the user is currently logged into Azure and has an active session.
.OUTPUTS
    Boolean. Returns $true if logged in, $false otherwise.
#>
function Test-AzureLogin {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    
    try {
        $context = Get-AzContext
        return ($null -ne $context -and $null -ne $context.Account)
    }
    catch {
        return $false
    }
}

# Export functions


