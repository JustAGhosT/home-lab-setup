<#
.SYNOPSIS
    Main deployment script for HomeLab Azure infrastructure
.DESCRIPTION
    Deploys Azure resources for a home lab environment including network, VPN gateway, and NAT gateway
.PARAMETER ENV
    Environment name (e.g., dev, test, prod)
.PARAMETER LOC
    Location code (e.g., we for West Europe)
.PARAMETER PROJECT
    Project name for resource naming
.PARAMETER LOCATION
    Azure region for deployment (e.g., westeurope)
.PARAMETER LogFile
    Path to log file
.PARAMETER ComponentsOnly
    Optional parameter to deploy only specific components ("network", "vpngateway", "natgateway")
.EXAMPLE
    Deploy-Infrastructure -ENV dev -LOC we -PROJECT homelab -LOCATION westeurope
.EXAMPLE
    Deploy-Infrastructure -ENV dev -LOC we -PROJECT homelab -LOCATION westeurope -ComponentsOnly "network"
#>

function Deploy-Infrastructure {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$ENV,
        
        [Parameter(Mandatory = $true)]
        [string]$LOC,
        
        [Parameter(Mandatory = $true)]
        [string]$PROJECT,
        
        [Parameter(Mandatory = $true)]
        [string]$LOCATION,
        
        [Parameter(Mandatory = $false)]
        [string]$LogFile = "$(Get-Location)\logs\deployment_$(Get-Date -Format 'yyyyMMdd_HHmmss').log",
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("network", "vpngateway", "natgateway", "")]
        [string]$ComponentsOnly = ""
    )

    # Define resource group name
    $RESOURCE_GROUP = "$ENV-$LOC-rg-$PROJECT"
    
    # Check Azure login
    Write-Log ">> Checking Azure login status..." -Color "White"
    $loggedIn = Connect-AzureAccount
    if (-not $loggedIn) {
        Write-Log "Azure login is required to continue. Exiting script." -Color "Red"
        return $false
    }
    
    # Check and prepare resource group
    $rgExists = Test-ResourceGroup -ResourceGroupName $RESOURCE_GROUP
    if ($rgExists) {
        $resetRg = Reset-ResourceGroup -ResourceGroupName $RESOURCE_GROUP
        if (-not $resetRg -and (Get-UserConfirmation -Message "Do you want to continue with the existing resource group?")) {
            Write-Log "Deployment cancelled by user." -Color "Yellow"
            return $false
        }
    } else {
        $created = New-AzureResourceGroup -ResourceGroupName $RESOURCE_GROUP -Location $LOCATION
        if (-not $created) {
            Write-Log "Failed to create resource group. Exiting script." -Color "Red"
            return $false
        }
    }
    
    # Deploy components based on selection
    switch ($ComponentsOnly) {
        "network" {
            Write-Log "Deploying network components only..." -Color "Cyan"
            Deploy-Network -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
        "vpngateway" {
            Write-Log "Deploying VPN Gateway only..." -Color "Cyan"
            Deploy-VpnGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
        "natgateway" {
            Write-Log "Deploying NAT Gateway only..." -Color "Cyan"
            Deploy-NatGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
        "" {
            Write-Log "Deploying all components..." -Color "Cyan"
            Deploy-Network -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
            Deploy-VpnGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
            Deploy-NatGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
    }
    
    Write-Log "Deployment completed successfully!" -Color "Green"
    return $true
}
