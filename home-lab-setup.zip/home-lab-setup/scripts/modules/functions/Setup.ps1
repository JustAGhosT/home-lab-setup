<#
.SYNOPSIS
    Setup functions for HomeLab
.DESCRIPTION
    Contains functions for initial setup and prerequisites checking
#>

function Test-Prerequisites {
    # Check if required tools are installed
    $azCliInstalled = $null -ne (Get-Command az -ErrorAction SilentlyContinue)
    $azPowerShellInstalled = $null -ne (Get-Module -ListAvailable Az.Accounts)
    
    return $azCliInstalled -and $azPowerShellInstalled
}

function Install-Prerequisites {
    # Install Azure CLI if not installed
    if ($null -eq (Get-Command az -ErrorAction SilentlyContinue)) {
        Write-Host "Installing Azure CLI..." -ForegroundColor Yellow
        Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi
        Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'
        Remove-Item .\AzureCLI.msi
    }
    
    # Install Az PowerShell module if not installed
    if ($null -eq (Get-Module -ListAvailable Az.Accounts)) {
        Write-Host "Installing Az PowerShell module..." -ForegroundColor Yellow
        Install-Module -Name Az -AllowClobber -Scope CurrentUser -Force
    }
    
    return $true
}

function Test-SetupComplete {
    # Check if setup has been completed
    $configFile = Join-Path -Path $env:USERPROFILE -ChildPath ".homelab\config.json"
    return Test-Path $configFile
}

function Initialize-HomeLab {
    # Create config directory if it doesn't exist
    $configDir = Join-Path -Path $env:USERPROFILE -ChildPath ".homelab"
    if (-not (Test-Path $configDir)) {
        New-Item -Path $configDir -ItemType Directory -Force | Out-Null
    }
    
    # Create default config file
    $configFile = Join-Path -Path $configDir -ChildPath "config.json"
    $defaultConfig = @{
        ENV = "dev"
        LOC = "we"
        PROJECT = "homelab"
        LOCATION = "westeurope"
        LastSetup = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    }
    
    $defaultConfig | ConvertTo-Json | Out-File -FilePath $configFile -Force
    
    return $true
}

function Start-HomeLab {
    # Display main menu and handle user input
    $selection = 0
    do {
        Show-MainMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Invoke-DeployMenu
            }
            "2" {
                # Implement configuration menu
                Write-Host "Configuration menu not implemented yet." -ForegroundColor Yellow
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                # Implement monitoring menu
                Write-Host "Monitoring menu not implemented yet." -ForegroundColor Yellow
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                Write-Host "Exiting HomeLab Setup..." -ForegroundColor Yellow
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Show-MainMenu {
    Clear-Host
    Write-Host "╔═══════════════════════════════════════╗" -ForegroundColor Blue
    Write-Host "║       HOMELAB SETUP - MAIN MENU       ║" -ForegroundColor Blue
    Write-Host "╚═══════════════════════════════════════╝" -ForegroundColor Blue
    Write-Host ""
    Write-Host "1. Deployment" -ForegroundColor Green
    Write-Host "2. Configuration" -ForegroundColor Green
    Write-Host "3. Monitoring" -ForegroundColor Green
    Write-Host ""
    Write-Host "0. Exit" -ForegroundColor Yellow
    Write-Host ""
}
