<#
.SYNOPSIS
    Component deployment functions for HomeLab
.DESCRIPTION
    Contains functions for deploying individual components like network, VPN gateway, and NAT gateway
#>

function Deploy-Network {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    Write-Log "Deploying network resources to resource group '$ResourceGroup'..." -Color "Cyan"
    
    # Create a virtual network
    $vnetName = "$ResourceGroup-vnet"
    $vnetAddressPrefix = "10.0.0.0/16"
    
    Write-Log "Creating virtual network '$vnetName'..." -Color "Cyan"
    az network vnet create --resource-group $ResourceGroup --name $vnetName --address-prefix $vnetAddressPrefix --location $Location
    
    # Create subnets
    $subnets = @(
        @{Name = "GatewaySubnet"; Prefix = "10.0.0.0/24"},
        @{Name = "AzureBastionSubnet"; Prefix = "10.0.1.0/24"},
        @{Name = "VMSubnet"; Prefix = "10.0.2.0/24"}
    )
    
    foreach ($subnet in $subnets) {
        Write-Log "Creating subnet '$($subnet.Name)'..." -Color "Cyan"
        az network vnet subnet create --resource-group $ResourceGroup --vnet-name $vnetName --name $subnet.Name --address-prefix $subnet.Prefix
    }
    
    Write-Log "Network deployment completed." -Color "Green"
    return $true
}

function Deploy-VpnGateway {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    Write-Log "Deploying VPN Gateway to resource group '$ResourceGroup'..." -Color "Cyan"
    
    # Create a public IP for the VPN Gateway
    $vpnGatewayPipName = "$ResourceGroup-vpn-pip"
    
    Write-Log "Creating public IP for VPN Gateway..." -Color "Cyan"
    az network public-ip create --resource-group $ResourceGroup --name $vpnGatewayPipName --allocation-method Dynamic --location $Location
    
    # Create the VPN Gateway
    $vnetName = "$ResourceGroup-vnet"
    $vpnGatewayName = "$ResourceGroup-vpn-gateway"
    
    Write-Log "Creating VPN Gateway '$vpnGatewayName'... (This may take 30-45 minutes)" -Color "Cyan"
    az network vnet-gateway create --resource-group $ResourceGroup --name $vpnGatewayName --public-ip-address $vpnGatewayPipName --vnet $vnetName --gateway-type Vpn --vpn-type RouteBased --sku VpnGw1 --location $Location --no-wait
    
    Write-Log "VPN Gateway deployment initiated. This will continue in the background." -Color "Green"
    return $true
}

function Deploy-NatGateway {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    Write-Log "Deploying NAT Gateway to resource group '$ResourceGroup'..." -Color "Cyan"
    
    # Create a public IP for the NAT Gateway
    $natGatewayPipName = "$ResourceGroup-nat-pip"
    
    Write-Log "Creating public IP for NAT Gateway..." -Color "Cyan"
    az network public-ip create --resource-group $ResourceGroup --name $natGatewayPipName --allocation-method Static --sku Standard --location $Location
    
    # Create the NAT Gateway
    $natGatewayName = "$ResourceGroup-nat-gateway"
    
    Write-Log "Creating NAT Gateway '$natGatewayName'..." -Color "Cyan"
    az network nat gateway create --resource-group $ResourceGroup --name $natGatewayName --public-ip-addresses $natGatewayPipName --location $Location
    
    # Associate the NAT Gateway with a subnet
    $vnetName = "$ResourceGroup-vnet"
    $subnetName = "VMSubnet"
    
    Write-Log "Associating NAT Gateway with subnet '$subnetName'..." -Color "Cyan"
    az network vnet subnet update --resource-group $ResourceGroup --vnet-name $vnetName --name $subnetName --nat-gateway $natGatewayName
    
    Write-Log "NAT Gateway deployment completed." -Color "Green"
    return $true
}
