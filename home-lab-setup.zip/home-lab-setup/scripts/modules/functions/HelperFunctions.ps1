<#
.SYNOPSIS
    Helper functions for HomeLab deployment
.DESCRIPTION
    Contains various helper functions used by the deployment process
#>

function Connect-AzureAccount {
    # This function should check if user is logged in to Azure and prompt for login if not
    # Returns $true if logged in successfully, $false otherwise
    try {
        $context = az account show 2>$null
        if ($null -eq $context) {
            Write-Log "Not logged in to Azure. Attempting to log in..." -Color "Yellow"
            az login
            $context = az account show 2>$null
            return ($null -ne $context)
        }
        return $true
    }
    catch {
        Write-Log "Error checking Azure login status: $_" -Color "Red"
        return $false
    }
}

function Test-ResourceGroup {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName
    )
    
    # Check if resource group exists
    try {
        $rg = az group show --name $ResourceGroupName 2>$null
        return ($null -ne $rg)
    }
    catch {
        return $false
    }
}

function Reset-ResourceGroup {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName
    )
    
    # Ask if user wants to reset the resource group
    $confirm = Get-UserConfirmation -Message "Resource group '$ResourceGroupName' already exists. Do you want to delete and recreate it?"
    if ($confirm) {
        Write-Log "Deleting resource group '$ResourceGroupName'..." -Color "Yellow"
        az group delete --name $ResourceGroupName --yes --no-wait
        
        # Wait for deletion to complete
        $deleted = $false
        $timeout = 300 # 5 minutes timeout
        $timer = [Diagnostics.Stopwatch]::StartNew()
        
        while (-not $deleted -and $timer.Elapsed.TotalSeconds -lt $timeout) {
            Start-Sleep -Seconds 10
            $exists = Test-ResourceGroup -ResourceGroupName $ResourceGroupName
            $deleted = -not $exists
        }
        
        if (-not $deleted) {
            Write-Log "Timed out waiting for resource group deletion." -Color "Red"
            return $false
        }
        
        # Recreate the resource group
        $location = az group show --name $ResourceGroupName --query location -o tsv 2>$null
        if (-not $location) {
            # If we couldn't get the location, use the one provided in parameters
            $location = $LOCATION
        }
        
        Write-Log "Creating resource group '$ResourceGroupName'..." -Color "Yellow"
        az group create --name $ResourceGroupName --location $location
        return $true
    }
    
    return $false
}

function Get-UserConfirmation {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message
    )
    
    $response = Read-Host "$Message (y/n)"
    return $response.ToLower() -eq 'y'
}

function Write-Log {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [string]$Color = "White",
        
        [Parameter(Mandatory = $false)]
        [string]$LogFile
    )
    
    # Write to console with color
    Write-Host $Message -ForegroundColor $Color
    
    # Write to log file if specified
    if ($LogFile) {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        "$timestamp - $Message" | Out-File -FilePath $LogFile -Append
    }
}
