<#
.SYNOPSIS
    Handles the deployment menu
.DESCRIPTION
    Processes user selections in the deployment menu
.EXAMPLE
    Invoke-DeployMenu
#>
function Invoke-DeployMenu {
    [CmdletBinding()]
    param()
    
    $selection = 0
    do {
        Show-DeployMenu
        $selection = Read-Host "Select an option"
        $params = Get-Configuration
        
        switch ($selection) {
            "1" {
                Write-Host "Starting full deployment..." -ForegroundColor Cyan
                Deploy-Infrastructure -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Deploying network only..." -ForegroundColor Cyan
                Deploy-Infrastructure -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile -ComponentsOnly "network"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Deploying VPN Gateway only..." -ForegroundColor Cyan
                Deploy-Infrastructure -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile -ComponentsOnly "vpngateway"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "4" {
                Write-Host "Deploying NAT Gateway only..." -ForegroundColor Cyan
                Deploy-Infrastructure -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile -ComponentsOnly "natgateway"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "5" {
                Write-Host "Checking deployment status..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                az group show --name $resourceGroup --query "properties.provisioningState" -o tsv
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Show-DeployMenu {
    Clear-Host
    Write-Host "╔═══════════════════════════════════════╗" -ForegroundColor Blue
    Write-Host "║       HOMELAB DEPLOYMENT MENU         ║" -ForegroundColor Blue
    Write-Host "╚═══════════════════════════════════════╝" -ForegroundColor Blue
    Write-Host ""
    Write-Host "1. Deploy All Components" -ForegroundColor Green
    Write-Host "2. Deploy Network Only" -ForegroundColor Green
    Write-Host "3. Deploy VPN Gateway Only" -ForegroundColor Green
    Write-Host "4. Deploy NAT Gateway Only" -ForegroundColor Green
    Write-Host "5. Check Deployment Status" -ForegroundColor Green
    Write-Host ""
    Write-Host "0. Return to Main Menu" -ForegroundColor Yellow
    Write-Host ""
}

function Get-Configuration {
    # This function should return the configuration parameters
    # You can implement it to read from a config file or use default values
    return @{
        ENV = "dev"
        LOC = "we"
        PROJECT = "homelab"
        LOCATION = "westeurope"
        LogFile = "$(Get-Location)\logs\deployment_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
    }
}
