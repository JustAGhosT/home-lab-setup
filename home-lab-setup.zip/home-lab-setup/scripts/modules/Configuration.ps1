<#
.SYNOPSIS
    Configuration management for HomeLab setup
.DESCRIPTION
    This module handles configuration loading, saving, and resetting for the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Default parameters
$script:params = @{
    ENV = "dev"
    LOC = "saf"
    PROJECT = "homelab"
    LOCATION = "southafricanorth"
    LogFile = "HomeLab_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
}

<#
.SYNOPSIS
    Gets the current configuration parameters
.DESCRIPTION
    Returns the current configuration parameters as a hashtable
.EXAMPLE
    $currentConfig = Get-Configuration
.OUTPUTS
    System.Collections.Hashtable. The current configuration parameters.
#>
function Get-Configuration {
    return $script:params
}

<#
.SYNOPSIS
    Updates a configuration parameter
.DESCRIPTION
    Updates a specific configuration parameter with a new value
.PARAMETER Name
    The name of the parameter to update
.PARAMETER Value
    The new value for the parameter
.EXAMPLE
    Update-ConfigurationParameter -Name "ENV" -Value "prod"
#>
function Update-ConfigurationParameter {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Name,
        
        [Parameter(Mandatory = $true)]
        [string]$Value
    )
    
    if ($script:params.ContainsKey($Name)) {
        $script:params[$Name] = $Value
        Write-Host "$Name updated to $Value" -ForegroundColor Green
    } else {
        Write-Host "Parameter $Name not found in configuration" -ForegroundColor Red
    }
}

<#
.SYNOPSIS
    Loads configuration from file
.DESCRIPTION
    Loads configuration settings from the config.json file
.EXAMPLE
    Load-Configuration
.OUTPUTS
    Boolean. Returns $true if configuration was loaded successfully, $false otherwise.
#>
function Load-Configuration {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    
    $scriptPath = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
    $configPath = Join-Path -Path $scriptPath -ChildPath "config.json"
    
    if (Test-Path $configPath) {
        try {
            $config = Get-Content -Path $configPath -Raw | ConvertFrom-Json
            
            $script:params.ENV = $config.env
            $script:params.LOC = $config.loc
            $script:params.PROJECT = $config.project
            $script:params.LOCATION = $config.location
            
            # Generate log file path with timestamp
            $logDir = $config.defaultLogFilePath
            if (-not (Test-Path $logDir)) {
                New-Item -ItemType Directory -Path $logDir -Force | Out-Null
            }
            $script:params.LogFile = Join-Path -Path $logDir -ChildPath "HomeLab_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
            
            Write-Host "Configuration loaded successfully" -ForegroundColor Green
            return $true
        }
        catch {
            Write-Host "Error loading configuration: $_" -ForegroundColor Red
            return $false
        }
    }
    else {
        Write-Host "Configuration file not found. Creating default configuration..." -ForegroundColor Yellow
        Save-Configuration
        return $true
    }
}

<#
.SYNOPSIS
    Saves configuration to file
.DESCRIPTION
    Saves the current configuration settings to the config.json file
.EXAMPLE
    Save-Configuration
.OUTPUTS
    Boolean. Returns $true if configuration was saved successfully, $false otherwise.
#>
function Save-Configuration {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    
    $scriptPath = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
    $configPath = Join-Path -Path $scriptPath -ChildPath "config.json"
    
    $config = @{
        env = $script:params.ENV
        loc = $script:params.LOC
        project = $script:params.PROJECT
        location = $script:params.LOCATION
        defaultLogFilePath = "HomeLab_Logs"
    }
    
    try {
        $config | ConvertTo-Json | Out-File -FilePath $configPath -Force
        Write-Host "Configuration saved successfully" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Host "Error saving configuration: $_" -ForegroundColor Red
        return $false
    }
}

<#
.SYNOPSIS
    Resets configuration to default values
.DESCRIPTION
    Resets all configuration parameters to their default values
.EXAMPLE
    Reset-Configuration
#>
function Reset-Configuration {
    [CmdletBinding()]
    param()
    
    $script:params.ENV = "dev"
    $script:params.LOC = "saf"
    $script:params.PROJECT = "homelab"
    $script:params.LOCATION = "southafricanorth"
    $script:params.LogFile = "HomeLab_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
    
    Save-Configuration
}

<#
.SYNOPSIS
    Gets user confirmation for an action
.DESCRIPTION
    Prompts the user for confirmation with customizable default response
.PARAMETER Message
    The message to display to the user
.PARAMETER DefaultYes
    If specified, the default response is Yes
.PARAMETER DefaultNo
    If specified, the default response is No
.EXAMPLE
    if (Get-UserConfirmation -Message "Are you sure?" -DefaultYes) { Do-Something }
.OUTPUTS
    Boolean. Returns $true if the user confirmed, $false otherwise.
#>
function Get-UserConfirmation {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [switch]$DefaultYes,
        
        [Parameter(Mandatory = $false)]
        [switch]$DefaultNo
    )
    
    if ($DefaultYes) {
        $prompt = "$Message (Y/n): "
        $defaultResponse = $true
    }
    elseif ($DefaultNo) {
        $prompt = "$Message (y/N): "
        $defaultResponse = $false
    }
    else {
        $prompt = "$Message (y/n): "
        $defaultResponse = $null
    }
    
    Write-Host $prompt -NoNewline -ForegroundColor Yellow
    $response = Read-Host
    
    if ([string]::IsNullOrWhiteSpace($response)) {
        return $defaultResponse
    }
    
    return $response.ToLower() -eq "y"
}

# Export functions


