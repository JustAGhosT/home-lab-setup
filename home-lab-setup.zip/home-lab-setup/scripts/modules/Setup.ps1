<#
.SYNOPSIS
    Setup functions for HomeLab environment
.DESCRIPTION
    This module contains functions for setting up the HomeLab environment.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Tests if setup is complete
.DESCRIPTION
    Checks if the HomeLab setup has been completed before
.EXAMPLE
    Test-SetupComplete
.OUTPUTS
    System.Boolean. Returns $true if setup is complete, $false otherwise.
#>
function Test-SetupComplete {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    
    # For testing purposes, always return false to trigger setup
    Write-Verbose "Checking if setup is complete..."
    
    # Check for setup marker file
    $scriptPath = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
    $setupMarkerPath = Join-Path -Path $scriptPath -ChildPath ".setup_complete"
    
    return Test-Path $setupMarkerPath
}

<#
.SYNOPSIS
    Initializes the HomeLab environment
.DESCRIPTION
    Performs first-time setup for the HomeLab environment
.EXAMPLE
    Initialize-HomeLab
.OUTPUTS
    System.Boolean. Returns $true if initialization was successful, $false otherwise.
#>
function Initialize-HomeLab {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    
    Write-Host "Initializing HomeLab environment..." -ForegroundColor Cyan
    
    # Load configuration
    if (-not (Load-Configuration)) {
        Write-Host "Creating default configuration..." -ForegroundColor Yellow
        Save-Configuration
    }
    
    # Initialize log file
    $params = Get-Configuration
    Initialize-LogFile -LogFilePath $params.LogFile
    
    Write-Log -Message "HomeLab initialization started" -Severity Information
    
    # Create setup marker file
    $scriptPath = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
    $setupMarkerPath = Join-Path -Path $scriptPath -ChildPath ".setup_complete"
    Set-Content -Path $setupMarkerPath -Value (Get-Date)
    
    Write-Host "HomeLab environment initialized successfully." -ForegroundColor Green
    Write-Log -Message "HomeLab initialization completed successfully" -Severity Information
    
    return $true
}

# Note: Removing 

