<#
.SYNOPSIS
    VPN management functions for HomeLab setup
.DESCRIPTION
    This module provides functions for managing VPN certificates, gateways, and clients.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Adds a certificate to a VPN gateway
.DESCRIPTION
    Adds a certificate to an Azure VPN gateway
.PARAMETER ResourceGroupName
    The name of the resource group containing the VPN gateway
.PARAMETER GatewayName
    The name of the VPN gateway
.PARAMETER CertificateName
    The name to give the certificate in Azure
.PARAMETER CertificateData
    The Base64 encoded certificate data
.EXAMPLE
    Add-VpnGatewayCertificate -ResourceGroupName "myRG" -GatewayName "myVPNGateway" -CertificateName "myRootCert" -CertificateData $certData
#>
function Add-VpnGatewayCertificate {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        
        [Parameter(Mandatory = $true)]
        [string]$GatewayName,
        
        [Parameter(Mandatory = $true)]
        [string]$CertificateName,
        
        [Parameter(Mandatory = $true)]
        [string]$CertificateData
    )
    
    try {
        Write-Log -Message "Adding certificate $CertificateName to VPN gateway $GatewayName" -Severity Information
        
        # Add certificate to VPN gateway
        az network vnet-gateway root-cert create --resource-group $ResourceGroupName --gateway-name $GatewayName --name $CertificateName --public-cert-data $CertificateData
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Certificate added successfully." -ForegroundColor Green
            Write-Log -Message "Certificate $CertificateName added successfully to VPN gateway $GatewayName" -Severity Information
        } else {
            Write-Host "Failed to add certificate." -ForegroundColor Red
            Write-Log -Message "Failed to add certificate $CertificateName to VPN gateway $GatewayName" -Severity Error
        }
    }
    catch {
        Write-Host "Error adding certificate: $_" -ForegroundColor Red
        Write-Log -Message "Error adding certificate: $_" -Severity Error
    }
}

<#
.SYNOPSIS
    Gets VPN client configuration
.DESCRIPTION
    Generates and downloads VPN client configuration from an Azure VPN gateway
.PARAMETER ResourceGroupName
    The name of the resource group containing the VPN gateway
.PARAMETER GatewayName
    The name of the VPN gateway
.PARAMETER OutputPath
    The path where the VPN client configuration will be saved
.EXAMPLE
    Get-VpnClientConfiguration -ResourceGroupName "myRG" -GatewayName "myVPNGateway" -OutputPath "C:\VPN\config.zip"
#>
function Get-VpnClientConfiguration {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        
        [Parameter(Mandatory = $true)]
        [string]$GatewayName,
        
        [Parameter(Mandatory = $true)]
        [string]$OutputPath
    )
    
    try {
        Write-Log -Message "Generating VPN client configuration for gateway $GatewayName" -Severity Information
        
        # Generate VPN client configuration
        az network vnet-gateway vpn-client generate --resource-group $ResourceGroupName --name $GatewayName --output-path $OutputPath
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "VPN client configuration generated successfully." -ForegroundColor Green
            Write-Host "Configuration saved to: $OutputPath" -ForegroundColor Green
            Write-Log -Message "VPN client configuration generated successfully and saved to $OutputPath" -Severity Information
        } else {
            Write-Host "Failed to generate VPN client configuration." -ForegroundColor Red
            Write-Log -Message "Failed to generate VPN client configuration for gateway $GatewayName" -Severity Error
        }
    }
    catch {
        Write-Host "Error generating VPN client configuration: $_" -ForegroundColor Red
        Write-Log -Message "Error generating VPN client configuration: $_" -Severity Error
    }
}

<#
.SYNOPSIS
    Creates a new self-signed root certificate
.DESCRIPTION
    Creates a new self-signed root certificate for VPN authentication
.PARAMETER CertName
    The name of the certificate
.PARAMETER OutputPath
    The path where the certificate file will be saved
.EXAMPLE
    New-SelfSignedRootCertificate -CertName "MyRootCert" -OutputPath "C:\Certs"
.OUTPUTS
    System.Security.Cryptography.X509Certificates.X509Certificate2. The created certificate.
#>
function New-SelfSignedRootCertificate {
    [CmdletBinding()]
    [OutputType([System.Security.Cryptography.X509Certificates.X509Certificate2])]
    param (
        [Parameter(Mandatory = $true)]
        [string]$CertName,
        
        [Parameter(Mandatory = $false)]
        [string]$OutputPath = $PWD
    )
    
    try {
        Write-Log -Message "Creating new self-signed root certificate: $CertName" -Severity Information
        
        # Create a self-signed root certificate
        $cert = New-SelfSignedCertificate -Type Custom -KeySpec Signature `
            -Subject "CN=$CertName" -KeyExportPolicy Exportable `
            -HashAlgorithm sha256 -KeyLength 2048 `
            -CertStoreLocation "Cert:\CurrentUser\My" -KeyUsageProperty Sign -KeyUsage CertSign
        
        # Export the public key
        $publicKeyPath = Join-Path -Path $OutputPath -ChildPath "$CertName.cer"
        Export-Certificate -Cert $cert -FilePath $publicKeyPath -Force | Out-Null
        
        # Export Base64 encoded data
        $base64Path = Join-Path -Path $OutputPath -ChildPath "$CertName.txt"
        $base64Data = [System.Convert]::ToBase64String($cert.RawData)
        Set-Content -Path $base64Path -Value $base64Data
        
        Write-Host "Root certificate created successfully." -ForegroundColor Green
        Write-Host "Public key saved to: $publicKeyPath" -ForegroundColor Green
        Write-Host "Base64 encoded data saved to: $base64Path" -ForegroundColor Green
        Write-Log -Message "Root certificate $CertName created successfully" -Severity Information
        
        return $cert
    }
    catch {
        Write-Host "Error creating root certificate: $_" -ForegroundColor Red
        Write-Log -Message "Error creating root certificate: $_" -Severity Error
        return $null
    }
}

<#
.SYNOPSIS
    Creates a new client certificate
.DESCRIPTION
    Creates a new client certificate signed by a root certificate
.PARAMETER RootCert
    The root certificate to sign with
.PARAMETER ClientCertName
    The name of the client certificate
.PARAMETER OutputPath
    The path where the certificate file will be saved
.EXAMPLE
    New-ClientCertificate -RootCert $rootCert -ClientCertName "MyClientCert" -OutputPath "C:\Certs"
.OUTPUTS
    System.Security.Cryptography.X509Certificates.X509Certificate2. The created certificate.
#>
function New-ClientCertificate {
    [CmdletBinding()]
    [OutputType([System.Security.Cryptography.X509Certificates.X509Certificate2])]
    param (
        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$RootCert,
        
        [Parameter(Mandatory = $true)]
        [string]$ClientCertName,
        
        [Parameter(Mandatory = $false)]
        [string]$OutputPath = $PWD
    )
    
    try {
        Write-Log -Message "Creating new client certificate: $ClientCertName" -Severity Information
        
        # Create a client certificate signed by the root
        $clientCert = New-SelfSignedCertificate -Type Custom -DnsName P2SChildCert -KeySpec Signature `
            -Subject "CN=$ClientCertName" -KeyExportPolicy Exportable `
            -HashAlgorithm sha256 -KeyLength 2048 `
            -CertStoreLocation "Cert:\CurrentUser\My" `
            -Signer $RootCert -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.2")
        
        # Export the public key
        $publicKeyPath = Join-Path -Path $OutputPath -ChildPath "$ClientCertName.cer"
        Export-Certificate -Cert $clientCert -FilePath $publicKeyPath -Force | Out-Null
        
        # Export the private key (PFX)
        $pfxPassword = ConvertTo-SecureString -String "Password1" -Force -AsPlainText
        $pfxPath = Join-Path -Path $OutputPath -ChildPath "$ClientCertName.pfx"
        Export-PfxCertificate -Cert $clientCert -FilePath $pfxPath -Password $pfxPassword -Force | Out-Null
        
        Write-Host "Client certificate created successfully." -ForegroundColor Green
        Write-Host "Public key saved to: $publicKeyPath" -ForegroundColor Green
        Write-Host "Private key saved to: $pfxPath (Password: Password1)" -ForegroundColor Green
        Write-Log -Message "Client certificate $ClientCertName created successfully" -Severity Information
        
        return $clientCert
    }
    catch {
        Write-Host "Error creating client certificate: $_" -ForegroundColor Red
        Write-Log -Message "Error creating client certificate: $_" -Severity Error
        return $null
    }
}