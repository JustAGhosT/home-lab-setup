<#
.SYNOPSIS
    Menu handler functions for HomeLab setup
.DESCRIPTION
    This module contains handler functions for menus in the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Import all menu modules
$menuPath = Join-Path -Path $PSScriptRoot -ChildPath "menu"
Get-ChildItem -Path $menuPath -Filter "*.ps1" | ForEach-Object {
    . $_.FullName
}

<#
.SYNOPSIS
    Starts the HomeLab application
.DESCRIPTION
    Initializes and runs the main HomeLab application
.EXAMPLE
    Start-HomeLab
#>
function Start-HomeLab {
    [CmdletBinding()]
    param()
    
    # Load configuration
    Load-Configuration
    
    # Initialize logging
    Initialize-LogFile -LogFilePath (Get-Configuration).LogFile
    
    # Main menu loop
    $selection = 0
    do {
        Show-MainMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Invoke-DeployMenu
            }
            "2" {
                Invoke-VpnCertMenu
            }
            "3" {
                Invoke-VpnGatewayMenu
            }
            "4" {
                Invoke-VpnClientMenu
            }
            "5" {
                Invoke-NatGatewayMenu
            }
            "6" {
                Invoke-DocumentationMenu
            }
            "7" {
                Invoke-SettingsMenu
            }
            "0" {
                Write-Host "Exiting Home Lab Setup..." -ForegroundColor Cyan
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

# Helper function to get user confirmation
function Get-UserConfirmation {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [switch]$DefaultNo
    )
    
    $choices = New-Object Collections.ObjectModel.Collection[Management.Automation.Host.ChoiceDescription]
    $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList "&Yes"))
    $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList "&No"))
    
    $defaultChoice = 0
    if ($DefaultNo) {
        $defaultChoice = 1
    }
    
    $result = $Host.UI.PromptForChoice("Confirmation", $Message, $choices, $defaultChoice)
    
    return ($result -eq 0)
}

# Export functions


