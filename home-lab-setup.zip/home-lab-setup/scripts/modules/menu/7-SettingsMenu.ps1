<#
.SYNOPSIS
    Settings menu handler for HomeLab setup
.DESCRIPTION
    This script handles the settings menu options for the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Handles the settings menu
.DESCRIPTION
    Processes user selections in the settings menu
.EXAMPLE
    Invoke-SettingsMenu
#>
function Invoke-SettingsMenu {
    [CmdletBinding()]
    param()
    
    $selection = 0
    do {
        Show-SettingsMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                $newEnv = Read-Host "Enter new environment (e.g., dev, test, prod)"
                if (-not [string]::IsNullOrWhiteSpace($newEnv)) {
                    Update-ConfigurationParameter -Name "ENV" -Value $newEnv
                    Save-Configuration
                }
                Start-Sleep -Seconds 1
            }
            "2" {
                $newLoc = Read-Host "Enter new location code (e.g., saf, use, euw)"
                if (-not [string]::IsNullOrWhiteSpace($newLoc)) {
                    Update-ConfigurationParameter -Name "LOC" -Value $newLoc
                    Save-Configuration
                }
                Start-Sleep -Seconds 1
            }
            "3" {
                $newProject = Read-Host "Enter new project name"
                if (-not [string]::IsNullOrWhiteSpace($newProject)) {
                    Update-ConfigurationParameter -Name "PROJECT" -Value $newProject
                    Save-Configuration
                }
                Start-Sleep -Seconds 1
            }
            "4" {
                $newLocation = Read-Host "Enter new Azure location (e.g., southafricanorth, eastus, westeurope)"
                if (-not [string]::IsNullOrWhiteSpace($newLocation)) {
                    Update-ConfigurationParameter -Name "LOCATION" -Value $newLocation
                    Save-Configuration
                }
                Start-Sleep -Seconds 1
            }
            "5" {
                if (Get-UserConfirmation -Message "Are you sure you want to reset to default settings?" -DefaultNo) {
                    Reset-Configuration
                    Write-Host "Settings reset to default values" -ForegroundColor Green
                }
                Start-Sleep -Seconds 1
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

# Export functions


