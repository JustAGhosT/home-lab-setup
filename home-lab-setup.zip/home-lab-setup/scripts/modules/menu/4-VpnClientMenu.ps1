<#
.SYNOPSIS
    VPN Client menu handler for HomeLab setup
.DESCRIPTION
    This script handles the VPN client menu options for the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Handles the VPN client management menu
.DESCRIPTION
    Processes user selections in the VPN client menu
.EXAMPLE
    Invoke-VpnClientMenu
#>
function Invoke-VpnClientMenu {
    [CmdletBinding()]
    param()
    
    $selection = 0
    do {
        Show-VpnClientMenu
        $selection = Read-Host "Select an option"
        $params = Get-Configuration
        $scriptPath = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))
        
        switch ($selection) {
            "1" {
                Write-Host "Adding computer to VPN..." -ForegroundColor Cyan
                & "$scriptPath\modules\VpnAddComputer.ps1"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Connecting to VPN..." -ForegroundColor Cyan
                & "$scriptPath\modules\VpnConnectDisconnect.ps1" -Connect
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Disconnecting from VPN..." -ForegroundColor Cyan
                & "$scriptPath\modules\VpnConnectDisconnect.ps1" -Disconnect
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "4" {
                Write-Host "Checking VPN connection status..." -ForegroundColor Cyan
                $connections = Get-VpnConnection | Where-Object { $_.Name -like "*$($params.PROJECT)*" }
                
                if ($connections) {
                    $connections | Format-Table -Property Name, ServerAddress, ConnectionStatus, AuthenticationMethod
                } else {
                    Write-Host "No VPN connections found for project $($params.PROJECT)." -ForegroundColor Yellow
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

# Export functions


