<#
.SYNOPSIS
    VPN Gateway menu handler for HomeLab setup
.DESCRIPTION
    This script handles the VPN gateway menu options for the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Handles the VPN gateway management menu
.DESCRIPTION
    Processes user selections in the VPN gateway menu
.EXAMPLE
    Invoke-VpnGatewayMenu
#>
function Invoke-VpnGatewayMenu {
    [CmdletBinding()]
    param()
    
    $selection = 0
    do {
        Show-VpnGatewayMenu
        $selection = Read-Host "Select an option"
        $params = Get-Configuration
        
        switch ($selection) {
            "1" {
                Write-Host "Checking VPN Gateway status..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                
                $status = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "provisioningState" -o tsv 2>$null
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "VPN Gateway Status: $status" -ForegroundColor Green
                    
                    # Get additional details
                    $gatewayType = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "gatewayType" -o tsv
                    $vpnType = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "vpnType" -o tsv
                    $sku = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "sku.name" -o tsv
                    
                    Write-Host "Gateway Type: $gatewayType" -ForegroundColor White
                    Write-Host "VPN Type: $vpnType" -ForegroundColor White
                    Write-Host "SKU: $sku" -ForegroundColor White
                } else {
                    Write-Host "VPN Gateway not found or error retrieving status." -ForegroundColor Red
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Generating VPN client configuration..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                
                $outputPath = Join-Path -Path $PWD -ChildPath "vpnclientconfiguration.zip"
                Get-VpnClientConfiguration -ResourceGroupName $resourceGroup -GatewayName $gatewayName -OutputPath $outputPath
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Adding certificate to VPN Gateway..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                $certName = "$($params.ENV)-$($params.PROJECT)-vpn-root"
                
                # Prompt for certificate file
                Write-Host "Select the Base64 encoded certificate file (.txt)..." -ForegroundColor Yellow
                $certFile = Read-Host "Enter path to certificate file"
                
                if (Test-Path $certFile) {
                    $certData = Get-Content $certFile -Raw
                    Add-VpnGatewayCertificate -ResourceGroupName $resourceGroup -GatewayName $gatewayName -CertificateName $certName -CertificateData $certData
                } else {
                    Write-Host "Certificate file not found." -ForegroundColor Red
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "4" {
                Write-Host "Removing certificate from VPN Gateway..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                
                # List existing certificates
                Write-Host "Existing certificates:" -ForegroundColor Yellow
                $certs = az network vnet-gateway root-cert list --resource-group $resourceGroup --gateway-name $gatewayName --query "[].name" -o tsv
                
                if ($certs) {
                    $certs -split "`n" | ForEach-Object { Write-Host "- $_" -ForegroundColor White }
                    
                    $certToRemove = Read-Host "Enter certificate name to remove"
                    
                    if (-not [string]::IsNullOrWhiteSpace($certToRemove)) {
                        az network vnet-gateway root-cert delete --resource-group $resourceGroup --gateway-name $gatewayName --name $certToRemove
                        
                        if ($LASTEXITCODE -eq 0) {
                            Write-Host "Certificate removed successfully." -ForegroundColor Green
                        } else {
                            Write-Host "Failed to remove certificate." -ForegroundColor Red
                        }
                    }
                } else {
                    Write-Host "No certificates found." -ForegroundColor Yellow
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

# Export functions


