<#
.SYNOPSIS
    Documentation menu handler for HomeLab setup
.DESCRIPTION
    This script handles the documentation menu options for the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Handles the documentation menu
.DESCRIPTION
    Processes user selections in the documentation menu
.EXAMPLE
    Invoke-DocumentationMenu
#>
function Invoke-DocumentationMenu {
    [CmdletBinding()]
    param()
    
    $selection = 0
    do {
        Show-DocumentationMenu
        $selection = Read-Host "Select an option"
        $scriptPath = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))
        
        switch ($selection) {
            "1" {
                Clear-Host
                Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
                Write-Host "║       MAIN README                        ║" -ForegroundColor Cyan
                Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
                Write-Host ""
                
                $readmePath = Join-Path -Path $scriptPath -ChildPath "README.md"
                if (Test-Path $readmePath) {
                    Get-Content $readmePath | ForEach-Object { Write-Host $_ }
                } else {
                    Write-Host "README.md not found." -ForegroundColor Red
                }
                
                Write-Host ""
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Clear-Host
                Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
                Write-Host "║       VPN GATEWAY DOCUMENTATION          ║" -ForegroundColor Cyan
                Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
                Write-Host ""
                
                $vpnReadmePath = Join-Path -Path $scriptPath -ChildPath "docs\VPN-GATEWAY.README.md"
                if (Test-Path $vpnReadmePath) {
                    Get-Content $vpnReadmePath | ForEach-Object { Write-Host $_ }
                } else {
                    Write-Host "VPN Gateway documentation not found." -ForegroundColor Red
                }
                
                Write-Host ""
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Clear-Host
                Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
                Write-Host "║    CLIENT CERTIFICATE MANAGEMENT GUIDE   ║" -ForegroundColor Cyan
                Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
                Write-Host ""
                
                $certGuidePath = Join-Path -Path $scriptPath -ChildPath "docs\client-certificate-management.md"
                if (Test-Path $certGuidePath) {
                    Get-Content $certGuidePath | ForEach-Object { Write-Host $_ }
                } else {
                    Write-Host "Client certificate management guide not found." -ForegroundColor Red
                }
                
                Write-Host ""
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

# Export functions


