<#
.SYNOPSIS
    NAT Gateway menu handler for HomeLab setup
.DESCRIPTION
    This script handles the NAT gateway menu options for the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Handles the NAT gateway management menu
.DESCRIPTION
    Processes user selections in the NAT gateway menu
.EXAMPLE
    Invoke-NatGatewayMenu
#>
function Invoke-NatGatewayMenu {
    [CmdletBinding()]
    param()
    
    $selection = 0
    do {
        Show-NatGatewayMenu
        $selection = Read-Host "Select an option"
        $params = Get-Configuration
        $scriptPath = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))
        
        switch ($selection) {
            "1" {
                Write-Host "Enabling NAT Gateway..." -ForegroundColor Cyan
                & "$scriptPath\modules\NatGatewayEnableDisable.ps1" -Enable -ResourceGroup "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Disabling NAT Gateway..." -ForegroundColor Cyan
                & "$scriptPath\modules\NatGatewayEnableDisable.ps1" -Disable -ResourceGroup "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Checking NAT Gateway status..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $natGatewayName = "$($params.ENV)-$($params.LOC)-natgw-$($params.PROJECT)"
                
                $status = az network nat gateway show --resource-group $resourceGroup --name $natGatewayName --query "provisioningState" -o tsv 2>$null
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "NAT Gateway Status: $status" -ForegroundColor Green
                    
                    # Get public IP addresses
                    $publicIps = az network nat gateway show --resource-group $resourceGroup --name $natGatewayName --query "publicIpAddresses[].id" -o tsv
                    
                    if ($publicIps) {
                        Write-Host "Associated Public IPs:" -ForegroundColor Yellow
                        $publicIps -split "`n" | ForEach-Object {
                            $ipName = $_ -replace ".*/", ""
                            $ipAddress = az network public-ip show --ids $_ --query "ipAddress" -o tsv
                            Write-Host "- $ipName : $ipAddress" -ForegroundColor White
                        }
                    }
                } else {
                    Write-Host "NAT Gateway not found or error retrieving status." -ForegroundColor Red
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

# Export functions


