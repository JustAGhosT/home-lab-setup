<#
.SYNOPSIS
    Main deployment script for HomeLab Azure infrastructure
.DESCRIPTION
    Deploys Azure resources for a home lab environment including network, VPN gateway, and NAT gateway
.PARAMETER ENV
    Environment name (e.g., dev, test, prod)
.PARAMETER LOC
    Location code (e.g., we for West Europe)
.PARAMETER PROJECT
    Project name for resource naming
.PARAMETER LOCATION
    Azure region for deployment (e.g., westeurope)
.PARAMETER LogFile
    Path to log file
.PARAMETER ComponentsOnly
    Optional parameter to deploy only specific components ("network", "vpngateway", "natgateway")
.EXAMPLE
    Deploy-Infrastructure -ENV dev -LOC we -PROJECT homelab -LOCATION westeurope
.EXAMPLE
    Deploy-Infrastructure -ENV dev -LOC we -PROJECT homelab -LOCATION westeurope -ComponentsOnly "network"
#>

function Deploy-Infrastructure {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$ENV,
        
        [Parameter(Mandatory = $true)]
        [string]$LOC,
        
        [Parameter(Mandatory = $true)]
        [string]$PROJECT,
        
        [Parameter(Mandatory = $true)]
        [string]$LOCATION,
        
        [Parameter(Mandatory = $false)]
        [string]$LogFile = "$(Get-Location)\logs\deployment_$(Get-Date -Format 'yyyyMMdd_HHmmss').log",
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("network", "vpngateway", "natgateway", "")]
        [string]$ComponentsOnly = ""
    )

    # Define resource group name
    $RESOURCE_GROUP = "$ENV-$LOC-rg-$PROJECT"
    
    # Check Azure login
    Write-Log ">> Checking Azure login status..." -Color "White"
    $loggedIn = Connect-AzureAccount
    if (-not $loggedIn) {
        Write-Log "Azure login is required to continue. Exiting script." -Color "Red"
        return $false
    }
    
    # Check and prepare resource group
    $rgExists = Test-ResourceGroup -ResourceGroupName $RESOURCE_GROUP
    if ($rgExists) {
        $resetRg = Reset-ResourceGroup -ResourceGroupName $RESOURCE_GROUP
        if (-not $resetRg -and (Get-UserConfirmation -Message "Do you want to continue with the existing resource group?")) {
            Write-Log "Deployment cancelled by user." -Color "Yellow"
            return $false
        }
    } else {
        $created = New-AzureResourceGroup -ResourceGroupName $RESOURCE_GROUP -Location $LOCATION
        if (-not $created) {
            Write-Log "Failed to create resource group. Exiting script." -Color "Red"
            return $false
        }
    }
    
    # Deploy components based on selection
    switch ($ComponentsOnly) {
        "network" {
            Write-Log "Deploying network components only..." -Color "Cyan"
            Deploy-Network -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
        "vpngateway" {
            Write-Log "Deploying VPN Gateway only..." -Color "Cyan"
            Deploy-VpnGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
        "natgateway" {
            Write-Log "Deploying NAT Gateway only..." -Color "Cyan"
            Deploy-NatGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
        "" {
            Write-Log "Deploying all components..." -Color "Cyan"
            Deploy-Network -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
            Deploy-VpnGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
            Deploy-NatGateway -ResourceGroup $RESOURCE_GROUP -Location $LOCATION
        }
    }
    
    Write-Log "Deployment completed successfully!" -Color "Green"
    return $true
}

# Helper functions that should be implemented or imported from other modules
function Connect-AzureAccount {
    # This function should check if user is logged in to Azure and prompt for login if not
    # Returns $true if logged in successfully, $false otherwise
    try {
        $context = az account show 2>$null
        if ($null -eq $context) {
            Write-Log "Not logged in to Azure. Attempting to log in..." -Color "Yellow"
            az login
            $context = az account show 2>$null
            return ($null -ne $context)
        }
        return $true
    }
    catch {
        Write-Log "Error checking Azure login status: $_" -Color "Red"
        return $false
    }
}

function Test-ResourceGroup {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName
    )
    
    # Check if resource group exists
    try {
        $rg = az group show --name $ResourceGroupName 2>$null
        return ($null -ne $rg)
    }
    catch {
        return $false
    }
}

function Reset-ResourceGroup {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName
    )
    
    # Ask if user wants to reset the resource group
    $confirm = Get-UserConfirmation -Message "Resource group '$ResourceGroupName' already exists. Do you want to delete and recreate it?"
    if ($confirm) {
        Write-Log "Deleting resource group '$ResourceGroupName'..." -Color "Yellow"
        az group delete --name $ResourceGroupName --yes --no-wait
        
        # Wait for deletion to complete
        $deleted = $false
        $timeout = 300 # 5 minutes timeout
        $timer = [Diagnostics.Stopwatch]::StartNew()
        
        while (-not $deleted -and $timer.Elapsed.TotalSeconds -lt $timeout) {
            Start-Sleep -Seconds 10
            $exists = Test-ResourceGroup -ResourceGroupName $ResourceGroupName
            $deleted = -not $exists
        }
        
        if (-not $deleted) {
            Write-Log "Timed out waiting for resource group deletion." -Color "Red"
            return $false
        }
        
        # Recreate the resource group
        $location = az group show --name $ResourceGroupName --query location -o tsv 2>$null
        if (-not $location) {
            # If we couldn't get the location, use the one provided in parameters
            $location = $LOCATION
        }
        
        Write-Log "Creating resource group '$ResourceGroupName'..." -Color "Yellow"
        az group create --name $ResourceGroupName --location $location
        return $true
    }
    
    return $false
}

function Get-UserConfirmation {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message
    )
    
    $response = Read-Host "$Message (y/n)"
    return $response.ToLower() -eq 'y'
}

function Deploy-Network {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    Write-Log "Deploying network resources to resource group '$ResourceGroup'..." -Color "Cyan"
    
    # Implement your network deployment logic here
    # Example: Deploy a virtual network and subnets
    
    # Create a virtual network
    $vnetName = "$ResourceGroup-vnet"
    $vnetAddressPrefix = "10.0.0.0/16"
    
    Write-Log "Creating virtual network '$vnetName'..." -Color "Cyan"
    az network vnet create --resource-group $ResourceGroup --name $vnetName --address-prefix $vnetAddressPrefix --location $Location
    
    # Create subnets
    $subnets = @(
        @{Name = "GatewaySubnet"; Prefix = "10.0.0.0/24"},
        @{Name = "AzureBastionSubnet"; Prefix = "10.0.1.0/24"},
        @{Name = "VMSubnet"; Prefix = "10.0.2.0/24"}
    )
    
    foreach ($subnet in $subnets) {
        Write-Log "Creating subnet '$($subnet.Name)'..." -Color "Cyan"
        az network vnet subnet create --resource-group $ResourceGroup --vnet-name $vnetName --name $subnet.Name --address-prefix $subnet.Prefix
    }
    
    Write-Log "Network deployment completed." -Color "Green"
    return $true
}

function Deploy-VpnGateway {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    Write-Log "Deploying VPN Gateway to resource group '$ResourceGroup'..." -Color "Cyan"
    
    # Implement your VPN Gateway deployment logic here
    # Example: Create a public IP and VPN gateway
    
    # Create a public IP for the VPN Gateway
    $vpnGatewayPipName = "$ResourceGroup-vpn-pip"
    
    Write-Log "Creating public IP for VPN Gateway..." -Color "Cyan"
    az network public-ip create --resource-group $ResourceGroup --name $vpnGatewayPipName --allocation-method Dynamic --location $Location
    
    # Create the VPN Gateway
    $vnetName = "$ResourceGroup-vnet"
    $vpnGatewayName = "$ResourceGroup-vpn-gateway"
    
    Write-Log "Creating VPN Gateway '$vpnGatewayName'... (This may take 30-45 minutes)" -Color "Cyan"
    az network vnet-gateway create --resource-group $ResourceGroup --name $vpnGatewayName --public-ip-address $vpnGatewayPipName --vnet $vnetName --gateway-type Vpn --vpn-type RouteBased --sku VpnGw1 --location $Location --no-wait
    
    Write-Log "VPN Gateway deployment initiated. This will continue in the background." -Color "Green"
    return $true
}

function Deploy-NatGateway {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    Write-Log "Deploying NAT Gateway to resource group '$ResourceGroup'..." -Color "Cyan"
    
    # Implement your NAT Gateway deployment logic here
    # Example: Create a public IP and NAT gateway
    
    # Create a public IP for the NAT Gateway
    $natGatewayPipName = "$ResourceGroup-nat-pip"
    
    Write-Log "Creating public IP for NAT Gateway..." -Color "Cyan"
    az network public-ip create --resource-group $ResourceGroup --name $natGatewayPipName --allocation-method Static --sku Standard --location $Location
    
    # Create the NAT Gateway
    $natGatewayName = "$ResourceGroup-nat-gateway"
    
    Write-Log "Creating NAT Gateway '$natGatewayName'..." -Color "Cyan"
    az network nat gateway create --resource-group $ResourceGroup --name $natGatewayName --public-ip-addresses $natGatewayPipName --location $Location
    
    # Associate the NAT Gateway with a subnet
    $vnetName = "$ResourceGroup-vnet"
    $subnetName = "VMSubnet"
    
    Write-Log "Associating NAT Gateway with subnet '$subnetName'..." -Color "Cyan"
    az network vnet subnet update --resource-group $ResourceGroup --vnet-name $vnetName --name $subnetName --nat-gateway $natGatewayName
    
    Write-Log "NAT Gateway deployment completed." -Color "Green"
    return $true
}

# Export the function
Export-ModuleMember -Function Deploy-Infrastructure
