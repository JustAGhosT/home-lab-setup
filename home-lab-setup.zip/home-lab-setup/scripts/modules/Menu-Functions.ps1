<#
.SYNOPSIS
    Menu display functions for HomeLab setup
.DESCRIPTION
    This module contains functions for displaying menus in the HomeLab setup.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

<#
.SYNOPSIS
    Displays the main menu
.DESCRIPTION
    Displays the main menu of the HomeLab setup
.EXAMPLE
    Show-MainMenu
#>
function Show-MainMenu {
    [CmdletBinding()]
    param()
    
    $params = Get-Configuration
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       HOME LAB SETUP - MAIN MENU         ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Deploy Azure Infrastructure" -ForegroundColor Green
    Write-Host " [2] VPN Certificate Management" -ForegroundColor Green
    Write-Host " [3] VPN Gateway Management" -ForegroundColor Green
    Write-Host " [4] VPN Client Management" -ForegroundColor Green
    Write-Host " [5] NAT Gateway Management" -ForegroundColor Green
    Write-Host " [6] View Documentation" -ForegroundColor Green
    Write-Host " [7] Configure Settings" -ForegroundColor Yellow
    Write-Host " [0] Exit" -ForegroundColor Red
    Write-Host ""
    Write-Host "Current Settings:" -ForegroundColor Cyan
    Write-Host " - Environment: $($params.ENV)" -ForegroundColor White
    Write-Host " - Location Code: $($params.LOC)" -ForegroundColor White
    Write-Host " - Project: $($params.PROJECT)" -ForegroundColor White
    Write-Host " - Azure Location: $($params.LOCATION)" -ForegroundColor White
    Write-Host " - Log File: $($params.LogFile)" -ForegroundColor White
    Write-Host ""
}

<#
.SYNOPSIS
    Displays the deployment menu
.DESCRIPTION
    Displays the deployment menu for infrastructure deployment
.EXAMPLE
    Show-DeployMenu
#>
function Show-DeployMenu {
    [CmdletBinding()]
    param()
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       INFRASTRUCTURE DEPLOYMENT          ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Full Deployment (All Resources)" -ForegroundColor Green
    Write-Host " [2] Deploy Network Only" -ForegroundColor Green
    Write-Host " [3] Deploy VPN Gateway Only" -ForegroundColor Green
    Write-Host " [4] Deploy NAT Gateway Only" -ForegroundColor Green
    Write-Host " [5] Check Deployment Status" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

<#
.SYNOPSIS
    Displays the VPN certificate management menu
.DESCRIPTION
    Displays the menu for VPN certificate management
.EXAMPLE
    Show-VpnCertMenu
#>
function Show-VpnCertMenu {
    [CmdletBinding()]
    param()
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       VPN CERTIFICATE MANAGEMENT         ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Create New Root Certificate" -ForegroundColor Green
    Write-Host " [2] Create Client Certificate" -ForegroundColor Green
    Write-Host " [3] Add Client Certificate to Existing Root" -ForegroundColor Green
    Write-Host " [4] Upload Certificate to VPN Gateway" -ForegroundColor Yellow
    Write-Host " [5] List All Certificates" -ForegroundColor White
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

<#
.SYNOPSIS
    Displays the VPN gateway management menu
.DESCRIPTION
    Displays the menu for VPN gateway management
.EXAMPLE
    Show-VpnGatewayMenu
#>
function Show-VpnGatewayMenu {
    [CmdletBinding()]
    param()
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       VPN GATEWAY MANAGEMENT             ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Check VPN Gateway Status" -ForegroundColor Green
    Write-Host " [2] Generate VPN Client Configuration" -ForegroundColor Green
    Write-Host " [3] Add Certificate to VPN Gateway" -ForegroundColor Green
    Write-Host " [4] Remove Certificate from VPN Gateway" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

<#
.SYNOPSIS
    Displays the VPN client management menu
.DESCRIPTION
    Displays the menu for VPN client management
.EXAMPLE
    Show-VpnClientMenu
#>
function Show-VpnClientMenu {
    [CmdletBinding()]
    param()
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       VPN CLIENT MANAGEMENT              ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Add Computer to VPN" -ForegroundColor Green
    Write-Host " [2] Connect to VPN" -ForegroundColor Green
    Write-Host " [3] Disconnect from VPN" -ForegroundColor Green
    Write-Host " [4] Check VPN Connection Status" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

<#
.SYNOPSIS
    Displays the NAT gateway management menu
.DESCRIPTION
    Displays the menu for NAT gateway management
.EXAMPLE
    Show-NatGatewayMenu
#>
function Show-NatGatewayMenu {
    [CmdletBinding()]
    param()
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       NAT GATEWAY MANAGEMENT             ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Enable NAT Gateway" -ForegroundColor Green
    Write-Host " [2] Disable NAT Gateway" -ForegroundColor Yellow
    Write-Host " [3] Check NAT Gateway Status" -ForegroundColor White
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

<#
.SYNOPSIS
    Displays the documentation menu
.DESCRIPTION
    Displays the menu for viewing documentation
.EXAMPLE
    Show-DocumentationMenu
#>
function Show-DocumentationMenu {
    [CmdletBinding()]
    param()
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       DOCUMENTATION                      ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] View Main README" -ForegroundColor Green
    Write-Host " [2] View VPN Gateway Documentation" -ForegroundColor Green
    Write-Host " [3] View Client Certificate Management Guide" -ForegroundColor Green
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

<#
.SYNOPSIS
    Displays the settings menu
.DESCRIPTION
    Displays the menu for configuring settings
.EXAMPLE
    Show-SettingsMenu
#>
function Show-SettingsMenu {
    [CmdletBinding()]
    param()
    
    $params = Get-Configuration
    
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       CONFIGURATION SETTINGS             ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Change Environment (Current: $($params.ENV))" -ForegroundColor Green
    Write-Host " [2] Change Location Code (Current: $($params.LOC))" -ForegroundColor Green
    Write-Host " [3] Change Project Name (Current: $($params.PROJECT))" -ForegroundColor Green
    Write-Host " [4] Change Azure Location (Current: $($params.LOCATION))" -ForegroundColor Green
    Write-Host " [5] Reset to Default Settings" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}


