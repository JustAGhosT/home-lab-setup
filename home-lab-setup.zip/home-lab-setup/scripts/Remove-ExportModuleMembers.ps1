# Get script path
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$modulesPath = Join-Path -Path $scriptPath -ChildPath "modules"

# Process all PS1 files in modules directory and subdirectories
Get-ChildItem -Path $modulesPath -Filter "*.ps1" -Recurse | ForEach-Object {
    Write-Host "Processing file: $($_.FullName)"
    
    # Read file content
    $content = Get-Content -Path $_.FullName -Raw
    
    # Replace Export-ModuleMember lines
    $newContent = $content -replace "Export-ModuleMember.*\r?\n", ""
    
    # Write back to file
    Set-Content -Path $_.FullName -Value $newContent
    
    Write-Host "Processed file: $($_.FullName)" -ForegroundColor Green
}

Write-Host "All Export-ModuleMember lines have been removed." -ForegroundColor Cyan
