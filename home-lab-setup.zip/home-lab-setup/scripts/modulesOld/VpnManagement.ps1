# modules\VpnManagement.ps1
# VPN Gateway management functions

function Wait-VpnGatewayProvisioning {
    param (
        [string]$ResourceGroupName,
        [string]$GatewayName,
        [int]$MaxRetries = 60
    )
    
    if (-not (Get-UserConfirmation -Message "Do you want to wait for VPN Gateway provisioning to complete?" -DefaultYes)) {
        Write-Log "Skipping VPN Gateway provisioning wait." -Color "Yellow"
        return $false
    }
    
    Write-Log "Waiting for VPN Gateway to be fully provisioned..." -Color "Cyan"
    Write-Log "This typically takes 30-45 minutes for initial deployment." -Color "Yellow"
    
    $retryCount = 0
    $progressChar = @('|', '/', '-', '\')
    
    while ($retryCount -lt $MaxRetries) {
        try {
            $char = $progressChar[$retryCount % $progressChar.Length]
            Write-Host "`r$char Checking VPN Gateway status (Attempt $($retryCount + 1) of $MaxRetries)..." -NoNewline
            [Console]::Out.Flush()
            
            $PROVISIONING_STATE = az network vnet-gateway show --resource-group $ResourceGroupName --name $GatewayName --query provisioningState -o tsv 2>$null
            
            if ($LASTEXITCODE -ne 0) {
                Write-Host "`r* VPN Gateway is still being created... (Attempt $($retryCount + 1) of $MaxRetries)     " -NoNewline
                [Console]::Out.Flush()
                Start-Sleep -Seconds 60
                $retryCount++
                continue
            }
            
            if ($PROVISIONING_STATE -eq "Succeeded") {
                Write-Host "`r                                                                                         "
                [Console]::Out.Flush()
                Write-Log "VPN Gateway is ready!" -Color "Green"
                return $true
            }
            else {
                Write-Host "`r* VPN Gateway status: $PROVISIONING_STATE (Attempt $($retryCount + 1) of $MaxRetries)     " -NoNewline
                [Console]::Out.Flush()
                Start-Sleep -Seconds 60
                $retryCount++
            }
        }
        catch {
            Write-Host "`r! Error checking VPN Gateway status. Retrying... (Attempt $($retryCount + 1) of $MaxRetries)     " -NoNewline
            [Console]::Out.Flush()
            Start-Sleep -Seconds 60
            $retryCount++
        }
    }
    
    Write-Host "" # New line after progress indicator
    [Console]::Out.Flush()
    
    if ($retryCount -ge $MaxRetries) {
        Write-Log "Maximum retry attempts reached. VPN Gateway provisioning may not be complete." -Color "Yellow"
        Write-Log "Continuing with the script, but VPN client configuration may fail." -Color "Yellow"
        return $false
    }
}

function Get-VpnClientConfiguration {
    param (
        [string]$ResourceGroupName,
        [string]$GatewayName,
        [string]$OutputPath = (Join-Path -Path $PWD -ChildPath "vpnclientconfiguration.zip")
    )
    
    if (-not (Get-UserConfirmation -Message "Do you want to generate VPN client configuration?" -DefaultYes)) {
        Write-Log "VPN client configuration generation skipped by user." -Color "Yellow"
        return $false
    }
    
    try {
        Write-Log "Generating VPN client profile..." -Color "Cyan"
        az network vnet-gateway vpn-client generate `
            --resource-group $ResourceGroupName `
            --name $GatewayName `
            --authentication-method EAPTLS
        
        if ($LASTEXITCODE -ne 0) {
            Write-Log "Failed to generate VPN client configuration." -Color "Red"
            return $false
        }
        
        # Download the VPN client configuration
        Write-Log "Downloading VPN client configuration..." -Color "Cyan"
        $vpnConfig = az network vnet-gateway vpn-client download `
            --resource-group $ResourceGroupName `
            --name $GatewayName `
            -o tsv
        
        if ($LASTEXITCODE -ne 0) {
            Write-Log "Failed to download VPN client configuration." -Color "Red"
            return $false
        }
        
        # Save the VPN client configuration to a file
        $vpnConfig | Out-File -FilePath $OutputPath -Encoding ascii
        Write-Log "VPN Client configuration saved to: $OutputPath" -Color "Green"
        return $true
    }
    catch {
        Write-Log "Error generating or downloading VPN client configuration: $_" -Color "Red"
        return $false
    }
}

function Add-VpnGatewayCertificate {
    param (
        [string]$ResourceGroupName,
        [string]$GatewayName,
        [string]$CertificateName,
        [string]$CertificateData
    )
    
    if (-not (Get-UserConfirmation -Message "Do you want to add the certificate to VPN Gateway?" -DefaultYes)) {
        Write-Log "Certificate addition skipped by user." -Color "Yellow"
        return $false
    }
    
    Write-Log "Adding root certificate to VPN Gateway..." -Color "Cyan"
    
    $result = az network vnet-gateway root-cert create `
        --resource-group $ResourceGroupName `
        --gateway-name $GatewayName `
        --name $CertificateName `
        --public-cert-data $CertificateData
    
    if ($LASTEXITCODE -eq 0) {
        Write-Log "Certificate added successfully to VPN Gateway." -Color "Green"
        return $true
    }
    else {
        Write-Log "Failed to add certificate to VPN Gateway: $result" -Color "Red"
        return $false
    }
}
