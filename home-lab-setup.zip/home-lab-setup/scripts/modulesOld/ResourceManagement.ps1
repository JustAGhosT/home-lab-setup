# modules\ResourceManagement.ps1
# Resource group management functions

function Test-ResourceGroup {
    param (
        [string]$ResourceGroupName
    )
    
    Write-Log "Checking if resource group $ResourceGroupName exists..." -Color "White"
    $rgExists = az group exists --name $ResourceGroupName
    
    if ($rgExists -eq "true") {
        Write-Log "RESOURCE GROUP STATUS: $ResourceGroupName ALREADY EXISTS." -Color "Yellow"
        return $true
    }
    
    return $false
}

function Reset-ResourceGroup {
    param (
        [string]$ResourceGroupName
    )
    
    if (-not (Get-UserConfirmation -Message "Do you want to delete and recreate the resource group?")) {
        return $false
    }
    
    Write-Log "Deleting resource group $ResourceGroupName..." -Color "Cyan"
    az group delete --name $ResourceGroupName --yes --no-wait
    
    # Wait for resource group deletion
    Write-Log "Waiting for resource group deletion to complete..." -Color "Cyan"
    $deleted = $false
    $attempts = 0
    $maxAttempts = 30
    
    while (-not $deleted -and $attempts -lt $maxAttempts) {
        $attempts++
        Write-Host "`rWaiting for deletion to complete... Attempt $attempts of $maxAttempts" -NoNewline
        [Console]::Out.Flush()
        Start-Sleep -Seconds 10
        $rgExists = az group exists --name $ResourceGroupName
        if ($rgExists -eq "false") {
            $deleted = $true
        }
    }
    
    Write-Host ""  # New line after progress
    [Console]::Out.Flush()
    
    if ($deleted) {
        Write-Log "Resource group deleted successfully." -Color "Green"
        return $true
    }
    else {
        Write-Log "Resource group deletion timed out. Please check the Azure portal." -Color "Red"
        return $false
    }
}

function New-AzureResourceGroup {
    param (
        [string]$ResourceGroupName,
        [string]$Location
    )
    
    if (-not (Get-UserConfirmation -Message "Do you want to create resource group '$ResourceGroupName'?" -DefaultYes)) {
        Write-Log "Resource group creation skipped by user." -Color "Yellow"
        return $false
    }
    
    Write-Log "Creating resource group $ResourceGroupName in $Location..." -Color "Cyan"
    
    $result = az group create --name $ResourceGroupName --location $Location
    
    if ($LASTEXITCODE -eq 0) {
        Write-Log "Resource group created successfully." -Color "Green"
        return $true
    }
    else {
        Write-Log "Failed to create resource group: $result" -Color "Red"
        return $false
    }
}
