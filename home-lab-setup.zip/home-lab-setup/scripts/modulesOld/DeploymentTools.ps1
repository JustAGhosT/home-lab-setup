# modules\DeploymentTools.ps1
# Bicep deployment functions

function Deploy-BicepTemplate {
    param (
        [string]$DeploymentName,
        [string]$Location,
        [string]$TemplateFile,
        [hashtable]$Parameters
    )
    
    # Convert parameters hashtable to command line arguments
    $paramString = ""
    foreach ($key in $Parameters.Keys) {
        $paramString += " --parameters $key=$($Parameters[$key])"
    }
    
    if (-not (Get-UserConfirmation -Message "Do you want to validate and deploy the Bicep template?" -DefaultYes)) {
        Write-Log "Bicep deployment skipped by user." -Color "Yellow"
        return $false
    }
    
    # Validate the template first
    Write-Log "Validating deployment template..." -Color "Cyan"
    $validationCmd = "az deployment sub validate --name $DeploymentName --location $Location --template-file $TemplateFile$paramString"
    Write-Log "Running: $validationCmd" -Color "White" -NoConsole
    
    $validationOutput = Invoke-Expression $validationCmd 2>&1
    
    if ($LASTEXITCODE -ne 0) {
        Write-Log "Template validation failed:" -Color "Red"
        Write-Log $validationOutput -Color "Red"
        
        # Check for specific errors
        if ($validationOutput -match "ResourceNotFound") {
            Write-Log "The error indicates a resource was not found. This is often because:" -Color "Yellow"
            Write-Log "1. A referenced resource doesn't exist yet" -Color "Yellow"
            Write-Log "2. There's a naming mismatch between resources" -Color "Yellow"
            Write-Log "3. The deployment order is incorrect" -Color "Yellow"
            
            Write-Log "Suggested fixes:" -Color "Green"
            Write-Log "* Add explicit 'dependsOn' properties in your Bicep files" -Color "White"
            Write-Log "* Check resource naming consistency across all files" -Color "White"
            Write-Log "* Ensure 'existing' resources are properly referenced" -Color "White"
        }
        
        if (-not (Get-UserConfirmation -Message "Do you want to attempt the deployment anyway?")) {
            return $false
        }
    }
    else {
        Write-Log "Template validation successful" -Color "Green"
    }
    
    # Execute the actual deployment
    Write-Log "Starting deployment..." -Color "Cyan"
    $deploymentCmd = "az deployment sub create --name $DeploymentName --location $Location --template-file $TemplateFile$paramString --verbose"
    Write-Log "Running: $deploymentCmd" -Color "White" -NoConsole
    
    $deploymentOutput = Invoke-Expression $deploymentCmd
    
    # Check deployment status
    if ($LASTEXITCODE -ne 0) {
        Write-Log "Deployment failed. Error details:" -Color "Red"
        Write-Log $deploymentOutput -Color "Red"
        
        # Offer to show detailed deployment operations
        if (Get-UserConfirmation -Message "Do you want to see detailed deployment operations?") {
            Write-Log "Fetching deployment operations..." -Color "Cyan"
            az deployment sub operation list --name $DeploymentName | Out-Host
        }
        
        return $false
    }
    else {
        Write-Log "Deployment completed successfully" -Color "Green"
        return $true
    }
}

function Show-DeploymentSummary {
    param (
        [string]$ResourceGroup,
        [string]$GatewayName,
        [string]$Location,
        [string]$Environment,
        [string]$VpnConfigPath,
        [string]$LogFilePath
    )
    
    Write-Log "+----------------------------------------+" -Color "Blue"
    Write-Log "|           DEPLOYMENT COMPLETED             |" -Color "Blue"
    Write-Log "+----------------------------------------+" -Color "Blue"
    Write-Log "Summary of deployed resources:" -Color "Cyan"
    Write-Log "* Resource Group: $ResourceGroup" -Color "White"
    Write-Log "* VPN Gateway: $GatewayName" -Color "White"
    Write-Log "* Location: $Location" -Color "White"
    Write-Log "* Environment: $Environment" -Color "White"
    Write-Log "* VPN Client Config: $VpnConfigPath" -Color "White"
    Write-Log "* Log File: $LogFilePath" -Color "White"

    Write-Log "Next Steps:" -Color "Green"
    Write-Log "1. Extract the VPN client configuration ZIP file" -Color "White"
    Write-Log "2. Install the VPN client configuration" -Color "White"
    Write-Log "3. Connect to your Azure Home Lab environment" -Color "White"

    Write-Log "Thank you for using the Azure Home Lab Deployment Tool!" -Color "Cyan"
}
