# Parameters
param (
    [Parameter(Mandatory=$true)]
    [ValidateSet("enable", "disable")]
    [string]$Action
)

# Configuration
$ENV = "dev"
$LOC = "saf"
$PROJECT = "homelab"
$LOCATION = "southafricanorth"
$RESOURCE_GROUP = "$ENV-$LOC-rg-$PROJECT"

# Function to write colored output
function Write-ColorOutput {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Message,
        
        [Parameter(Mandatory=$true)]
        [string]$Color
    )
    
    $originalColor = $host.UI.RawUI.ForegroundColor
    $host.UI.RawUI.ForegroundColor = $Color
    Write-Output $Message
    $host.UI.RawUI.ForegroundColor = $originalColor
}

# Deploy the NAT Gateway with the appropriate setting
if ($Action -eq "enable") {
    $enableNatGateway = $true
    Write-ColorOutput "Enabling NAT Gateway..." "Green"
} else {
    $enableNatGateway = $false
    Write-ColorOutput "Disabling NAT Gateway..." "Yellow"
}

# Deploy the NAT Gateway module with the appropriate setting
az deployment group create `
  --resource-group $RESOURCE_GROUP `
  --template-file nat-gateway.bicep `
  --parameters location=$LOCATION env=$ENV loc=$LOC project=$PROJECT enableNatGateway=$enableNatGateway

if ($LASTEXITCODE -eq 0) {
    if ($Action -eq "enable") {
        Write-ColorOutput "NAT Gateway has been successfully enabled!" "Green"
        Write-Output "Your VMs can now access the internet through the NAT Gateway."
    } else {
        Write-ColorOutput "NAT Gateway has been successfully disabled!" "Yellow"
        Write-Output "Your VMs will no longer use the NAT Gateway for outbound connections."
    }
} else {
    Write-ColorOutput "Failed to $Action the NAT Gateway. Please check the error messages above." "Red"
}