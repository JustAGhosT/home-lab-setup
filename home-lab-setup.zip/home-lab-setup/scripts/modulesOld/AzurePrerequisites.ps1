# modules\AzurePrerequisites.ps1
# Azure CLI and login prerequisites

function Test-AzureCLI {
    try {
        $azVersion = az --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            return $true
        }
        return $false
    }
    catch {
        return $false
    }
}

function Install-AzureCLI {
    Write-Log "Azure CLI not found. Installing Azure CLI..." -Color "Yellow"
    
    if (-not (Get-UserConfirmation -Message "Do you want to install Azure CLI?" -DefaultYes)) {
        Write-Log "Azure CLI installation skipped by user." -Color "Yellow"
        return $false
    }
    
    try {
        # Check if running with admin privileges
        $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
        
        if (-not $isAdmin) {
            Write-Log "This script needs to be run as Administrator to install Azure CLI." -Color "Red"
            Write-Log "Please restart PowerShell as Administrator and run this script again." -Color "Red"
            return $false
        }
        
        # Download and install Azure CLI
        $ProgressPreference = 'SilentlyContinue'  # Hide progress bar for faster download
        Write-Log "Downloading Azure CLI installer..." -Color "Cyan"
        Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi
        
        Write-Log "Installing Azure CLI (this may take a few minutes)..." -Color "Cyan"
        Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'
        Remove-Item .\AzureCLI.msi
        
        # Refresh environment variables
        Write-Log "Refreshing environment variables..." -Color "Cyan"
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        
        # Verify installation
        if (Test-AzureCLI) {
            Write-Log "Azure CLI installed successfully!" -Color "Green"
            return $true
        }
        else {
            Write-Log "Azure CLI installation failed. Please install manually: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows" -Color "Red"
            return $false
        }
    }
    catch {
        Write-Log "Error installing Azure CLI: $_" -Color "Red"
        Write-Log "Please install Azure CLI manually: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows" -Color "Yellow"
        return $false
    }
}

function Test-AzureLogin {
    try {
        $account = az account show 2>&1
        if ($LASTEXITCODE -eq 0) {
            return $true
        }
        return $false
    }
    catch {
        return $false
    }
}

function Connect-AzureAccount {
    if (-not (Test-AzureLogin)) {
        Write-Log "You need to log in to Azure to continue." -Color "Yellow"
        
        if (-not (Get-UserConfirmation -Message "Do you want to log in to Azure now?" -DefaultYes)) {
            Write-Log "Azure login skipped by user. Exiting script." -Color "Red"
            return $false
        }
        
        [Console]::Out.Flush()
        az login
        if ($LASTEXITCODE -ne 0) {
            Write-Log "Azure login failed. Please try again." -Color "Red"
            return $false
        }
        else {
            Write-Log "Successfully logged in to Azure" -Color "Green"
            return $true
        }
    }
    else {
        Write-Log "Already logged in to Azure" -Color "Green"
        
        # Show current subscription
        $subscription = az account show --query "name" -o tsv
        $subscriptionId = az account show --query "id" -o tsv
        Write-Log "Current subscription: $subscription ($subscriptionId)" -Color "Cyan"
        return $true
    }
}

function Test-AzureCliPrerequisites {
    if (-not (Test-AzureCLI)) {
        $installed = Install-AzureCLI
        if (-not $installed) {
            return $false
        }
    }
    else {
        Write-Log "Azure CLI is installed" -Color "Green"
    }
    return $true
}
