<#
.SYNOPSIS
  Connects to or disconnects from the Azure VPN.

.DESCRIPTION
  This script connects to or disconnects from the Azure VPN connection.
  It also displays the current connection status.

.PARAMETER Action
  The action to perform: Connect, Disconnect, or Status.

.PARAMETER ConnectionName
  Name of the VPN connection (default: "HomeLab VPN").
#>

param (
  [Parameter(Mandatory=$true)]
  [ValidateSet("Connect", "Disconnect", "Status")]
  [string]$Action,
  
  [Parameter(Mandatory=$false)]
  [string]$ConnectionName = "HomeLab VPN"
)

function Get-VpnStatus {
  param (
    [string]$ConnectionName
  )
  
  $connection = Get-VpnConnection -Name $ConnectionName -ErrorAction SilentlyContinue
  
  if (-not $connection) {
    Write-Host "VPN connection '$ConnectionName' not found." -ForegroundColor Red
    Write-Host "Please run Setup-VpnClient.ps1 first to set up the VPN connection." -ForegroundColor Yellow
    return $false
  }
  
  $status = $connection.ConnectionStatus
  
  if ($status -eq "Connected") {
    Write-Host "VPN Status: Connected" -ForegroundColor Green
    
    # Get connection details
    $connectionStats = Get-NetIPConfiguration | Where-Object { 
      $_.InterfaceAlias -like "*$ConnectionName*" 
    }
    
    if ($connectionStats) {
      $ipAddress = $connectionStats.IPv4Address.IPAddress
      $dnsServers = ($connectionStats.DNSServer | Where-Object { $_.Address -ne "fec0:0:0:ffff::1" -and $_.Address -ne "fec0:0:0:ffff::2" -and $_.Address -ne "fec0:0:0:ffff::3" }).Address -join ", "
      
      Write-Host "IP Address: $ipAddress" -ForegroundColor Cyan
      Write-Host "DNS Servers: $dnsServers" -ForegroundColor Cyan
      
      # Get connection time
      $netAdapter = Get-NetAdapter | Where-Object { $_.InterfaceDescription -like "*$ConnectionName*" }
      if ($netAdapter) {
        $connectionTime = (Get-Date) - $netAdapter.LastConnect
        $formattedTime = "{0:D2}:{1:D2}:{2:D2}" -f $connectionTime.Hours, $connectionTime.Minutes, $connectionTime.Seconds
        Write-Host "Connection Time: $formattedTime" -ForegroundColor Cyan
      }
    }
    
    return $true
  } else {
    Write-Host "VPN Status: Disconnected" -ForegroundColor Yellow
    return $false
  }
}

# Check if the VPN connection exists
$connection = Get-VpnConnection -Name $ConnectionName -ErrorAction SilentlyContinue
if (-not $connection -and $Action -ne "Status") {
  Write-Host "VPN connection '$ConnectionName' not found." -ForegroundColor Red
  Write-Host "Please run Setup-VpnClient.ps1 first to set up the VPN connection." -ForegroundColor Yellow
  exit 1
}

# Perform the requested action
switch ($Action) {
  "Connect" {
    Write-Host "Connecting to '$ConnectionName'..." -ForegroundColor Cyan
    
    # Check if already connected
    $isConnected = Get-VpnStatus -ConnectionName $ConnectionName
    if ($isConnected) {
      Write-Host "Already connected to '$ConnectionName'." -ForegroundColor Green
      exit 0
    }
    
    # Connect to the VPN
    try {
      rasdial $ConnectionName
      if ($LASTEXITCODE -eq 0) {
        Write-Host "Successfully connected to '$ConnectionName'." -ForegroundColor Green
        Get-VpnStatus -ConnectionName $ConnectionName
      } else {
        Write-Host "Failed to connect to '$ConnectionName'." -ForegroundColor Red
      }
    } catch {
      Write-Host "Error connecting to VPN: $_" -ForegroundColor Red
    }
  }
  
  "Disconnect" {
    Write-Host "Disconnecting from '$ConnectionName'..." -ForegroundColor Cyan
    
    # Check if already disconnected
    $isConnected = Get-VpnStatus -ConnectionName $ConnectionName
    if (-not $isConnected) {
      Write-Host "Already disconnected from '$ConnectionName'." -ForegroundColor Yellow
      exit 0
    }
    
    # Disconnect from the VPN
    try {
      rasdial $ConnectionName /disconnect
      if ($LASTEXITCODE -eq 0) {
        Write-Host "Successfully disconnected from '$ConnectionName'." -ForegroundColor Green
      } else {
        Write-Host "Failed to disconnect from '$ConnectionName'." -ForegroundColor Red
      }
    } catch {
      Write-Host "Error disconnecting from VPN: $_" -ForegroundColor Red
    }
  }
  
  "Status" {
    Get-VpnStatus -ConnectionName $ConnectionName
  }
}
