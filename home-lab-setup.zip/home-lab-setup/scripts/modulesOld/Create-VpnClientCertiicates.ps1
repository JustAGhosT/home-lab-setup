<#
.SYNOPSIS
    Creates and manages client certificates for Azure VPN Gateway P2S connections.

.DESCRIPTION
    This script helps you create a root certificate and client certificates for Azure VPN Gateway
    Point-to-Site (P2S) connections. It can also export certificates in the required formats
    for Azure VPN Gateway configuration and client installation.

.PARAMETER RootCertName
    Name for the root certificate.

.PARAMETER ClientCertName
    Name for the client certificate.

.PARAMETER ExportPath
    Path where certificates will be exported.

.PARAMETER ClientCertPassword
    Password to protect the exported client certificate (.pfx).

.PARAMETER CreateNewRoot
    Switch to create a new root certificate. If not specified, the script will attempt to use an existing one.

.EXAMPLE
    .\Create-VpnClientCertificates.ps1 -RootCertName "P2SVPNRoot" -ClientCertName "JohnDoeVPN" -ExportPath "C:\Certificates"

.EXAMPLE
    .\Create-VpnClientCertificates.ps1 -CreateNewRoot -RootCertName "NewVPNRoot" -ClientCertName "DeviceVPN" -ExportPath "C:\Certificates" -ClientCertPassword "SecurePass123"
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [string]$RootCertName = "P2SVPNRootCert",
    
    [Parameter(Mandatory=$false)]
    [string]$ClientCertName = "P2SVPNClientCert",
    
    [Parameter(Mandatory=$false)]
    [string]$ExportPath = "$env:USERPROFILE\Documents\VPNCertificates",
    
    [Parameter(Mandatory=$false)]
    [string]$ClientCertPassword,
    
    [Parameter(Mandatory=$false)]
    [switch]$CreateNewRoot
)

# Create export directory if it doesn't exist
if (-not (Test-Path -Path $ExportPath)) {
    New-Item -ItemType Directory -Path $ExportPath -Force | Out-Null
    Write-Host "Created directory: $ExportPath" -ForegroundColor Green
}

# Function to get or create root certificate
function Get-OrCreateRootCertificate {
    param (
        [string]$CertName,
        [bool]$CreateNew
    )
    
    # Check if certificate already exists
    $existingCert = Get-ChildItem -Path Cert:\CurrentUser\My | Where-Object { $_.Subject -eq "CN=$CertName" -and $_.HasPrivateKey }
    
    if ($existingCert -and -not $CreateNew) {
        Write-Host "Using existing root certificate: $CertName" -ForegroundColor Yellow
        return $existingCert
    }
    else {
        Write-Host "Creating new root certificate: $CertName" -ForegroundColor Green
        $rootCert = New-SelfSignedCertificate -Type Custom -KeySpec Signature `
            -Subject "CN=$CertName" -KeyExportPolicy Exportable `
            -HashAlgorithm sha256 -KeyLength 2048 `
            -CertStoreLocation "Cert:\CurrentUser\My" -KeyUsageProperty Sign -KeyUsage CertSign
        return $rootCert
    }
}

# Function to create client certificate
function New-ClientCertificate {
    param (
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$RootCert,
        [string]$ClientName
    )
    
    Write-Host "Creating client certificate: $ClientName" -ForegroundColor Green
    $clientCert = New-SelfSignedCertificate -Type Custom -DnsName $ClientName -KeySpec Signature `
        -Subject "CN=$ClientName" -KeyExportPolicy Exportable `
        -HashAlgorithm sha256 -KeyLength 2048 `
        -CertStoreLocation "Cert:\CurrentUser\My" `
        -Signer $RootCert -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.2")
    
    return $clientCert
}

# Function to export certificates
function Export-VpnCertificates {
    param (
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$RootCert,
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$ClientCert,
        [string]$ExportPath,
        [string]$ClientCertPassword
    )
    
    # Export root certificate (.cer) for Azure Portal
    $rootCerPath = Join-Path -Path $ExportPath -ChildPath "$($RootCert.Subject.Substring(3)).cer"
    Export-Certificate -Cert $RootCert -FilePath $rootCerPath -Type CERT | Out-Null
    Write-Host "Root certificate exported to: $rootCerPath" -ForegroundColor Green
    
    # Export root certificate with private key (.pfx) for backup
    $rootPfxPath = Join-Path -Path $ExportPath -ChildPath "$($RootCert.Subject.Substring(3)).pfx"
    
    if (-not $ClientCertPassword) {
        $securePassword = Read-Host "Enter password for root certificate export" -AsSecureString
    }
    else {
        $securePassword = ConvertTo-SecureString -String $ClientCertPassword -Force -AsPlainText
    }
    
    Export-PfxCertificate -Cert $RootCert -FilePath $rootPfxPath -Password $securePassword | Out-Null
    Write-Host "Root certificate with private key exported to: $rootPfxPath" -ForegroundColor Green
    
    # Export client certificate (.pfx) for client installation
    $clientPfxPath = Join-Path -Path $ExportPath -ChildPath "$($ClientCert.Subject.Substring(3)).pfx"
    
    if (-not $ClientCertPassword) {
        $securePassword = Read-Host "Enter password for client certificate export" -AsSecureString
    }
    else {
        $securePassword = ConvertTo-SecureString -String $ClientCertPassword -Force -AsPlainText
    }
    
    Export-PfxCertificate -Cert $ClientCert -FilePath $clientPfxPath -Password $securePassword | Out-Null
    Write-Host "Client certificate exported to: $clientPfxPath" -ForegroundColor Green
    
    # Generate Base64 string of the root certificate for Azure Portal
    $rootCertData = [System.Convert]::ToBase64String([System.IO.File]::ReadAllBytes($rootCerPath))
    $rootCertDataPath = Join-Path -Path $ExportPath -ChildPath "$($RootCert.Subject.Substring(3))_Base64.txt"
    $rootCertData | Out-File -FilePath $rootCertDataPath
    Write-Host "Base64 encoded root certificate data saved to: $rootCertDataPath" -ForegroundColor Green
    
    return @{
        RootCerPath = $rootCerPath
        RootPfxPath = $rootPfxPath
        ClientPfxPath = $clientPfxPath
        RootCertBase64Path = $rootCertDataPath
    }
}

# Main execution
try {
    Write-Host "=== Azure VPN Gateway Client Certificate Management ===" -ForegroundColor Cyan
    
    # Get or create root certificate
    $rootCert = Get-OrCreateRootCertificate -CertName $RootCertName -CreateNew $CreateNewRoot
    
    # Create client certificate
    $clientCert = New-ClientCertificate -RootCert $rootCert -ClientName $ClientCertName
    
    # Export certificates
    $exportedFiles = Export-VpnCertificates -RootCert $rootCert -ClientCert $clientCert -ExportPath $ExportPath -ClientCertPassword $ClientCertPassword
    
    Write-Host "`n=== Certificate Creation Complete ===" -ForegroundColor Cyan
    Write-Host "`nNext Steps for Azure VPN Gateway Configuration:" -ForegroundColor Yellow
    Write-Host "1. Upload the root certificate to Azure VPN Gateway" -ForegroundColor White
    Write-Host "   - Use the Base64 data from: $($exportedFiles.RootCertBase64Path)" -ForegroundColor White
    Write-Host "2. Install the client certificate on each device" -ForegroundColor White
    Write-Host "   - Use the client PFX file: $($exportedFiles.ClientPfxPath)" -ForegroundColor White
    Write-Host "3. Download and configure the VPN client from Azure Portal" -ForegroundColor White
    
    # Display certificate thumbprints for reference
    Write-Host "`nCertificate Information:" -ForegroundColor Yellow
    Write-Host "Root Certificate Thumbprint: $($rootCert.Thumbprint)" -ForegroundColor White
    Write-Host "Client Certificate Thumbprint: $($clientCert.Thumbprint)" -ForegroundColor White
}
catch {
    Write-Host "Error: $_" -ForegroundColor Red
    Write-Host "Stack Trace: $($_.Exception.StackTrace)" -ForegroundColor Red
}

# Add function to create additional client certificates using the same root
function Add-AdditionalClientCertificate {
    param (
        [Parameter(Mandatory=$true)]
        [string]$NewClientName,
        
        [Parameter(Mandatory=$false)]
        [string]$ClientPassword
    )
    
    # Find the root certificate
    $rootCert = Get-ChildItem -Path Cert:\CurrentUser\My | Where-Object { $_.Subject -eq "CN=$RootCertName" -and $_.HasPrivateKey }
    
    if (-not $rootCert) {
        Write-Host "Root certificate not found. Please run the script first to create a root certificate." -ForegroundColor Red
        return
    }
    
    # Create new client certificate
    $newClientCert = New-ClientCertificate -RootCert $rootCert -ClientName $NewClientName
    
    # Export client certificate
    $clientPfxPath = Join-Path -Path $ExportPath -ChildPath "$NewClientName.pfx"
    
    if (-not $ClientPassword) {
        $securePassword = Read-Host "Enter password for client certificate export" -AsSecureString
    }
    else {
        $securePassword = ConvertTo-SecureString -String $ClientPassword -Force -AsPlainText
    }
    
    Export-PfxCertificate -Cert $newClientCert -FilePath $clientPfxPath -Password $securePassword | Out-Null
    Write-Host "New client certificate exported to: $clientPfxPath" -ForegroundColor Green
    Write-Host "Client Certificate Thumbprint: $($newClientCert.Thumbprint)" -ForegroundColor White
}

# Example of how to use the additional function (commented out)
# Add-AdditionalClientCertificate -NewClientName "AdditionalDevice" -ClientPassword "SecurePass123"