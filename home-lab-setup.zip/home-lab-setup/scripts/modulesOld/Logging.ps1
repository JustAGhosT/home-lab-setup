# modules\Logging.ps1
# Logging functions

function Initialize-LogFile {
    param (
        [string]$LogFilePath
    )
    
    if (-not (Test-Path -Path $LogFilePath)) {
        $null = New-Item -ItemType File -Path $LogFilePath -Force
    }
    
    Add-Content -Path $LogFilePath -Value "===== Azure Deployment Log - $(Get-Date) ====="
    Add-Content -Path $LogFilePath -Value "Environment: $ENV"
    Add-Content -Path $LogFilePath -Value "Location: $LOCATION"
    Add-Content -Path $LogFilePath -Value "Project: $PROJECT"
    Add-Content -Path $LogFilePath -Value "========================================"
}

function Write-Log {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [string]$Color = "White",
        
        [Parameter(Mandatory = $false)]
        [switch]$NoConsole,
        
        [Parameter(Mandatory = $false)]
        [switch]$NoLog
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] $Message"
    
    if (-not $NoLog -and (Get-Variable -Name LogFile -ErrorAction SilentlyContinue)) {
        Add-Content -Path $LogFile -Value $logMessage
    }
    
    if (-not $NoConsole) {
        Write-Host $Message -ForegroundColor $Color
        [Console]::Out.Flush()
    }
}

function Show-Spinner {
    param (
        [string]$Activity = "Processing",
        [int]$DurationSeconds = 1
    )
    
    $spinner = @('|', '/', '-', '\')
    $startTime = Get-Date
    $endTime = $startTime.AddSeconds($DurationSeconds)
    
    $i = 0
    while ((Get-Date) -lt $endTime) {
        Write-Host "`r$Activity $($spinner[$i % 4])" -NoNewline
        [Console]::Out.Flush()
        Start-Sleep -Milliseconds 250
        $i++
    }
    Write-Host "`r$Activity Complete!     "
    [Console]::Out.Flush()
}

function Get-UserConfirmation {
    param (
        [string]$Message,
        [switch]$DefaultYes
    )
    
    $prompt = if ($DefaultYes) { "$Message (Y/n): " } else { "$Message (y/N): " }
    Write-Host $prompt -NoNewline -ForegroundColor Yellow
    [Console]::Out.Flush()
    
    $response = Read-Host
    
    if ($DefaultYes) {
        return ($response -ne "n")
    }
    else {
        return ($response -eq "y")
    }
}
