<#
.SYNOPSIS
  Sets up the Azure VPN Client on a Windows computer.

.DESCRIPTION
  This script extracts the VPN client configuration from the downloaded zip file,
  installs the necessary certificates, and sets up the VPN connection.

.PARAMETER VpnConfigZipPath
  Path to the VPN client configuration zip file downloaded from Azure.

.PARAMETER ConnectionName
  Name for the VPN connection (default: "HomeLab VPN").
#>

param (
  [Parameter(Mandatory=$true)]
  [string]$VpnConfigZipPath,
  
  [Parameter(Mandatory=$false)]
  [string]$ConnectionName = "HomeLab VPN"
)

# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
  Write-Error "This script must be run as Administrator. Please restart PowerShell as Administrator and try again."
  exit 1
}

# Create a temporary directory
$tempDir = Join-Path $env:TEMP "AzureVPN_$(Get-Random)"
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

try {
  # Extract the zip file
  Write-Host "Extracting VPN configuration..." -ForegroundColor Cyan
  Expand-Archive -Path $VpnConfigZipPath -DestinationPath $tempDir -Force
  
  # Find the Windows client directory
  $windowsDir = Get-ChildItem -Path $tempDir -Filter "WindowsAmd64" -Directory
  if (-not $windowsDir) {
    $windowsDir = Get-ChildItem -Path $tempDir -Filter "WindowsClient" -Directory
  }
  
  if (-not $windowsDir) {
    Write-Error "Could not find Windows client directory in the VPN configuration package."
    exit 1
  }
  
  $clientDir = $windowsDir.FullName
  
  # Install the VPN client
  Write-Host "Installing VPN client..." -ForegroundColor Cyan
  $installerPath = Join-Path $clientDir "VpnClientSetupAmd64.exe"
  if (Test-Path $installerPath) {
    Start-Process -FilePath $installerPath -ArgumentList "/quiet" -Wait
  } else {
    Write-Warning "VPN client installer not found. Continuing with manual configuration..."
  }
  
  # Import certificates
  Write-Host "Importing certificates..." -ForegroundColor Cyan
  $certPath = Join-Path $clientDir "VpnServerRoot.cer"
  if (Test-Path $certPath) {
    Import-Certificate -FilePath $certPath -CertStoreLocation Cert:\LocalMachine\Root | Out-Null
    Write-Host "Root certificate imported successfully." -ForegroundColor Green
  } else {
    Write-Error "Root certificate not found."
    exit 1
  }
  
  # Find the VPN configuration file
  $vpnProfilePath = Join-Path $clientDir "Generic\VpnSettings.xml"
  if (-not (Test-Path $vpnProfilePath)) {
    Write-Error "VPN profile configuration not found."
    exit 1
  }
  
  # Read the VPN configuration
  [xml]$vpnConfig = Get-Content $vpnProfilePath
  $vpnServerAddress = $vpnConfig.VpnProfile.VpnServer
  
  # Check if the VPN connection already exists
  $existingConnection = Get-VpnConnection -Name $ConnectionName -ErrorAction SilentlyContinue
  if ($existingConnection) {
    Write-Host "Removing existing VPN connection '$ConnectionName'..." -ForegroundColor Yellow
    Remove-VpnConnection -Name $ConnectionName -Force -ErrorAction SilentlyContinue
  }
  
  # Create the VPN connection
  Write-Host "Creating VPN connection '$ConnectionName'..." -ForegroundColor Cyan
  
  # Create the VPN connection
  Add-VpnConnection -Name $ConnectionName `
                    -ServerAddress $vpnServerAddress `
                    -TunnelType "Ikev2" `
                    -EncryptionLevel "Maximum" `
                    -AuthenticationMethod "EAP" `
                    -RememberCredential $true `
                    -SplitTunneling $true `
                    -Force
  
  # Set the VPN connection to use machine certificates
  $vpnConnectionProps = Get-VpnConnectionProperties -Name $ConnectionName
  $vpnConnectionProps.AuthenticationTransformConstants.MachineCertificateEku = "1.3.6.1.5.5.7.3.2"
  Set-VpnConnectionProperties -Name $ConnectionName -VpnConnectionProperties $vpnConnectionProps
  
  Write-Host "VPN connection '$ConnectionName' has been set up successfully!" -ForegroundColor Green
  Write-Host "You can now connect to the VPN using the Connect-VPN.ps1 script." -ForegroundColor Green
  
} finally {
  # Clean up
  if (Test-Path $tempDir) {
    Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
  }
}
