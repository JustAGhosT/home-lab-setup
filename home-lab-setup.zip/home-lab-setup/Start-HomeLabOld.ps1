<#
.SYNOPSIS
    Home Lab Setup - Main Entry Point
.DESCRIPTION
    This script serves as the main entry point for the Home Lab Setup project,
    providing a menu-driven interface to access all functionality.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Import all module files
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$modulesPath = Join-Path -Path $scriptPath -ChildPath "modules"

# Import all module files
Get-ChildItem -Path $modulesPath -Filter "*.ps1" | ForEach-Object {
    . $_.FullName
}

# Default parameters
$params = @{
    ENV = "dev"
    LOC = "saf"
    PROJECT = "homelab"
    LOCATION = "southafricanorth"
    LogFile = "HomeLab_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
}

# Initialize logging
Initialize-LogFile -LogFilePath $params.LogFile

function Show-MainMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       HOME LAB SETUP - MAIN MENU         ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Deploy Azure Infrastructure" -ForegroundColor Green
    Write-Host " [2] VPN Certificate Management" -ForegroundColor Green
    Write-Host " [3] VPN Gateway Management" -ForegroundColor Green
    Write-Host " [4] VPN Client Management" -ForegroundColor Green
    Write-Host " [5] NAT Gateway Management" -ForegroundColor Green
    Write-Host " [6] View Documentation" -ForegroundColor Green
    Write-Host " [7] Configure Settings" -ForegroundColor Yellow
    Write-Host " [0] Exit" -ForegroundColor Red
    Write-Host ""
    Write-Host "Current Settings:" -ForegroundColor Cyan
    Write-Host " - Environment: $($params.ENV)" -ForegroundColor White
    Write-Host " - Location Code: $($params.LOC)" -ForegroundColor White
    Write-Host " - Project: $($params.PROJECT)" -ForegroundColor White
    Write-Host " - Azure Location: $($params.LOCATION)" -ForegroundColor White
    Write-Host " - Log File: $($params.LogFile)" -ForegroundColor White
    Write-Host ""
}

function Show-DeployMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       INFRASTRUCTURE DEPLOYMENT          ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Full Deployment (All Resources)" -ForegroundColor Green
    Write-Host " [2] Deploy Network Only" -ForegroundColor Green
    Write-Host " [3] Deploy VPN Gateway Only" -ForegroundColor Green
    Write-Host " [4] Deploy NAT Gateway Only" -ForegroundColor Green
    Write-Host " [5] Check Deployment Status" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

function Show-VpnCertMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       VPN CERTIFICATE MANAGEMENT         ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Create New Root Certificate" -ForegroundColor Green
    Write-Host " [2] Create Client Certificate" -ForegroundColor Green
    Write-Host " [3] Add Client Certificate to Existing Root" -ForegroundColor Green
    Write-Host " [4] Upload Certificate to VPN Gateway" -ForegroundColor Yellow
    Write-Host " [5] List All Certificates" -ForegroundColor White
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

function Show-VpnGatewayMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       VPN GATEWAY MANAGEMENT             ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Check VPN Gateway Status" -ForegroundColor Green
    Write-Host " [2] Generate VPN Client Configuration" -ForegroundColor Green
    Write-Host " [3] Add Certificate to VPN Gateway" -ForegroundColor Green
    Write-Host " [4] Remove Certificate from VPN Gateway" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

function Show-VpnClientMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       VPN CLIENT MANAGEMENT              ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Add Computer to VPN" -ForegroundColor Green
    Write-Host " [2] Connect to VPN" -ForegroundColor Green
    Write-Host " [3] Disconnect from VPN" -ForegroundColor Green
    Write-Host " [4] Check VPN Connection Status" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

function Show-NatGatewayMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       NAT GATEWAY MANAGEMENT             ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Enable NAT Gateway" -ForegroundColor Green
    Write-Host " [2] Disable NAT Gateway" -ForegroundColor Yellow
    Write-Host " [3] Check NAT Gateway Status" -ForegroundColor White
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

function Show-DocumentationMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       DOCUMENTATION                      ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] View Main README" -ForegroundColor Green
    Write-Host " [2] View VPN Gateway Documentation" -ForegroundColor Green
    Write-Host " [3] View Client Certificate Management Guide" -ForegroundColor Green
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

function Show-SettingsMenu {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       CONFIGURATION SETTINGS             ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " [1] Change Environment (Current: $($params.ENV))" -ForegroundColor Green
    Write-Host " [2] Change Location Code (Current: $($params.LOC))" -ForegroundColor Green
    Write-Host " [3] Change Project Name (Current: $($params.PROJECT))" -ForegroundColor Green
    Write-Host " [4] Change Azure Location (Current: $($params.LOCATION))" -ForegroundColor Green
    Write-Host " [5] Reset to Default Settings" -ForegroundColor Yellow
    Write-Host " [0] Return to Main Menu" -ForegroundColor Red
    Write-Host ""
}

function Invoke-DeployMenu {
    $selection = 0
    do {
        Show-DeployMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Write-Host "Starting full deployment..." -ForegroundColor Cyan
                & "$scriptPath\deploy.ps1" -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Deploying network only..." -ForegroundColor Cyan
                # Call the appropriate function or script
                & "$scriptPath\deploy.ps1" -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile -ComponentsOnly "network"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Deploying VPN Gateway only..." -ForegroundColor Cyan
                # Call the appropriate function or script
                & "$scriptPath\deploy.ps1" -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile -ComponentsOnly "vpngateway"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "4" {
                Write-Host "Deploying NAT Gateway only..." -ForegroundColor Cyan
                # Call the appropriate function or script
                & "$scriptPath\deploy.ps1" -ENV $params.ENV -LOC $params.LOC -PROJECT $params.PROJECT -LOCATION $params.LOCATION -LogFile $params.LogFile -ComponentsOnly "natgateway"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "5" {
                Write-Host "Checking deployment status..." -ForegroundColor Cyan
                # Call function to check deployment status
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                az group show --name $resourceGroup --query "properties.provisioningState" -o tsv
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Invoke-VpnCertMenu {
    $selection = 0
    do {
        Show-VpnCertMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Write-Host "Creating new root certificate..." -ForegroundColor Cyan
                $rootCertName = "$($params.ENV)-$($params.PROJECT)-vpn-root"
                $clientCertName = "$($params.ENV)-$($params.PROJECT)-vpn-client"
                & "$scriptPath\modules\Create-VpnClientCertificates.ps1" -RootCertName $rootCertName -ClientCertName $clientCertName -CreateNewRoot
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Creating client certificate..." -ForegroundColor Cyan
                $rootCertName = "$($params.ENV)-$($params.PROJECT)-vpn-root"
                $clientCertName = Read-Host "Enter client certificate name"
                if ([string]::IsNullOrWhiteSpace($clientCertName)) {
                    $clientCertName = "$($params.ENV)-$($params.PROJECT)-vpn-client"
                }
                & "$scriptPath\modules\Create-VpnClientCertificates.ps1" -RootCertName $rootCertName -ClientCertName $clientCertName
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Adding client certificate to existing root..." -ForegroundColor Cyan
                $rootCertName = "$($params.ENV)-$($params.PROJECT)-vpn-root"
                $newClientName = Read-Host "Enter new client name"
                if (-not [string]::IsNullOrWhiteSpace($newClientName)) {
                    # Using the Add-AdditionalClientCertificate function from Create-VpnClientCertificates.ps1
                    & "$scriptPath\modules\Create-VpnClientCertificates.ps1"
                    Add-AdditionalClientCertificate -NewClientName $newClientName
                }
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "4" {
                Write-Host "Uploading certificate to VPN Gateway..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                $certName = "$($params.ENV)-$($params.PROJECT)-vpn-root"
                
                # Prompt for certificate file
                Write-Host "Select the Base64 encoded certificate file (.txt)..." -ForegroundColor Yellow
                $certFile = Read-Host "Enter path to certificate file"
                
                if (Test-Path $certFile) {
                    $certData = Get-Content $certFile -Raw
                    Add-VpnGatewayCertificate -ResourceGroupName $resourceGroup -GatewayName $gatewayName -CertificateName $certName -CertificateData $certData
                } else {
                    Write-Host "Certificate file not found." -ForegroundColor Red
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "5" {
                Write-Host "Listing all certificates..." -ForegroundColor Cyan
                $rootCertName = "$($params.ENV)-$($params.PROJECT)-vpn-root"
                
                Write-Host "Root Certificates:" -ForegroundColor Yellow
                Get-ChildItem -Path Cert:\CurrentUser\My | Where-Object { $_.Subject -like "CN=$rootCertName*" } | 
                    Format-Table -Property Subject, Thumbprint, NotBefore, NotAfter
                
                Write-Host "Client Certificates:" -ForegroundColor Yellow
                Get-ChildItem -Path Cert:\CurrentUser\My | Where-Object { $_.Subject -like "CN=$($params.ENV)-$($params.PROJECT)-vpn-client*" } | 
                    Format-Table -Property Subject, Thumbprint, NotBefore, NotAfter
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Invoke-VpnGatewayMenu {
    $selection = 0
    do {
        Show-VpnGatewayMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Write-Host "Checking VPN Gateway status..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                
                $status = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "provisioningState" -o tsv 2>$null
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "VPN Gateway Status: $status" -ForegroundColor Green
                    
                    # Get additional details
                    $gatewayType = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "gatewayType" -o tsv
                    $vpnType = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "vpnType" -o tsv
                    $sku = az network vnet-gateway show --resource-group $resourceGroup --name $gatewayName --query "sku.name" -o tsv
                    
                    Write-Host "Gateway Type: $gatewayType" -ForegroundColor White
                    Write-Host "VPN Type: $vpnType" -ForegroundColor White
                    Write-Host "SKU: $sku" -ForegroundColor White
                } else {
                    Write-Host "VPN Gateway not found or error retrieving status." -ForegroundColor Red
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Generating VPN client configuration..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                
                $outputPath = Join-Path -Path $PWD -ChildPath "vpnclientconfiguration.zip"
                Get-VpnClientConfiguration -ResourceGroupName $resourceGroup -GatewayName $gatewayName -OutputPath $outputPath
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Adding certificate to VPN Gateway..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                $certName = "$($params.ENV)-$($params.PROJECT)-vpn-root"
                
                # Prompt for certificate file
                Write-Host "Select the Base64 encoded certificate file (.txt)..." -ForegroundColor Yellow
                $certFile = Read-Host "Enter path to certificate file"
                
                if (Test-Path $certFile) {
                    $certData = Get-Content $certFile -Raw
                    Add-VpnGatewayCertificate -ResourceGroupName $resourceGroup -GatewayName $gatewayName -CertificateName $certName -CertificateData $certData
                } else {
                    Write-Host "Certificate file not found." -ForegroundColor Red
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "4" {
                Write-Host "Removing certificate from VPN Gateway..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $gatewayName = "$($params.ENV)-$($params.LOC)-vpng-$($params.PROJECT)"
                
                # List existing certificates
                Write-Host "Existing certificates:" -ForegroundColor Yellow
                $certs = az network vnet-gateway root-cert list --resource-group $resourceGroup --gateway-name $gatewayName --query "[].name" -o tsv
                
                if ($certs) {
                    $certs -split "`n" | ForEach-Object { Write-Host "- $_" -ForegroundColor White }
                    
                    $certToRemove = Read-Host "Enter certificate name to remove"
                    
                    if (-not [string]::IsNullOrWhiteSpace($certToRemove)) {
                        az network vnet-gateway root-cert delete --resource-group $resourceGroup --gateway-name $gatewayName --name $certToRemove
                        
                        if ($LASTEXITCODE -eq 0) {
                            Write-Host "Certificate removed successfully." -ForegroundColor Green
                        } else {
                            Write-Host "Failed to remove certificate." -ForegroundColor Red
                        }
                    }
                } else {
                    Write-Host "No certificates found." -ForegroundColor Yellow
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Invoke-VpnClientMenu {
    $selection = 0
    do {
        Show-VpnClientMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Write-Host "Adding computer to VPN..." -ForegroundColor Cyan
                & "$scriptPath\modules\VpnAddComputer.ps1"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Connecting to VPN..." -ForegroundColor Cyan
                & "$scriptPath\modules\VpnConnectDisconnect.ps1" -Connect
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Disconnecting from VPN..." -ForegroundColor Cyan
                & "$scriptPath\modules\VpnConnectDisconnect.ps1" -Disconnect
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "4" {
                Write-Host "Checking VPN connection status..." -ForegroundColor Cyan
                $connections = Get-VpnConnection | Where-Object { $_.Name -like "*$($params.PROJECT)*" }
                
                if ($connections) {
                    $connections | Format-Table -Property Name, ServerAddress, ConnectionStatus, AuthenticationMethod
                } else {
                    Write-Host "No VPN connections found for project $($params.PROJECT)." -ForegroundColor Yellow
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Invoke-NatGatewayMenu {
    $selection = 0
    do {
        Show-NatGatewayMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Write-Host "Enabling NAT Gateway..." -ForegroundColor Cyan
                & "$scriptPath\modules\NatGatewayEnableDisable.ps1" -Enable -ResourceGroup "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Write-Host "Disabling NAT Gateway..." -ForegroundColor Cyan
                & "$scriptPath\modules\NatGatewayEnableDisable.ps1" -Disable -ResourceGroup "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Write-Host "Checking NAT Gateway status..." -ForegroundColor Cyan
                $resourceGroup = "$($params.ENV)-$($params.LOC)-rg-$($params.PROJECT)"
                $natGatewayName = "$($params.ENV)-$($params.LOC)-natgw-$($params.PROJECT)"
                
                $status = az network nat gateway show --resource-group $resourceGroup --name $natGatewayName --query "provisioningState" -o tsv 2>$null
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "NAT Gateway Status: $status" -ForegroundColor Green
                    
                    # Get public IP addresses
                    $publicIps = az network nat gateway show --resource-group $resourceGroup --name $natGatewayName --query "publicIpAddresses[].id" -o tsv
                    
                    if ($publicIps) {
                        Write-Host "Associated Public IPs:" -ForegroundColor Yellow
                        $publicIps -split "`n" | ForEach-Object {
                            $ipName = $_ -replace ".*/", ""
                            $ipAddress = az network public-ip show --ids $_ --query "ipAddress" -o tsv
                            Write-Host "- $ipName : $ipAddress" -ForegroundColor White
                        }
                    }
                } else {
                    Write-Host "NAT Gateway not found or error retrieving status." -ForegroundColor Red
                }
                
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Invoke-DocumentationMenu {
    $selection = 0
    do {
        Show-DocumentationMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Clear-Host
                Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
                Write-Host "║       MAIN README                        ║" -ForegroundColor Cyan
                Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
                Write-Host ""
                
                $readmePath = Join-Path -Path $scriptPath -ChildPath "README.md"
                if (Test-Path $readmePath) {
                    Get-Content $readmePath | ForEach-Object { Write-Host $_ }
                } else {
                    Write-Host "README.md not found." -ForegroundColor Red
                }
                
                Write-Host ""
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "2" {
                Clear-Host
                Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
                Write-Host "║       VPN GATEWAY DOCUMENTATION          ║" -ForegroundColor Cyan
                Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
                Write-Host ""
                
                $vpnReadmePath = Join-Path -Path $scriptPath -ChildPath "docs\VPN-GATEWAY.README.md"
                if (Test-Path $vpnReadmePath) {
                    Get-Content $vpnReadmePath | ForEach-Object { Write-Host $_ }
                } else {
                    Write-Host "VPN Gateway documentation not found." -ForegroundColor Red
                }
                
                Write-Host ""
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "3" {
                Clear-Host
                Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
                Write-Host "║    CLIENT CERTIFICATE MANAGEMENT GUIDE   ║" -ForegroundColor Cyan
                Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
                Write-Host ""
                
                $certGuidePath = Join-Path -Path $scriptPath -ChildPath "docs\client-certificate-management.md"
                if (Test-Path $certGuidePath) {
                    Get-Content $certGuidePath | ForEach-Object { Write-Host $_ }
                } else {
                    Write-Host "Client certificate management guide not found." -ForegroundColor Red
                }
                
                Write-Host ""
                Write-Host "Press any key to continue..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Invoke-SettingsMenu {
    $selection = 0
    do {
        Show-SettingsMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                $newEnv = Read-Host "Enter new environment (e.g., dev, test, prod)"
                if (-not [string]::IsNullOrWhiteSpace($newEnv)) {
                    $params.ENV = $newEnv
                    Save-Configuration
                    Write-Host "Environment updated to $($params.ENV)" -ForegroundColor Green
                }
                Start-Sleep -Seconds 1
            }
            "2" {
                $newLoc = Read-Host "Enter new location code (e.g., saf, use, euw)"
                if (-not [string]::IsNullOrWhiteSpace($newLoc)) {
                    $params.LOC = $newLoc
                    Save-Configuration
                    Write-Host "Location code updated to $($params.LOC)" -ForegroundColor Green
                }
                Start-Sleep -Seconds 1
            }
            "3" {
                $newProject = Read-Host "Enter new project name"
                if (-not [string]::IsNullOrWhiteSpace($newProject)) {
                    $params.PROJECT = $newProject
                    Save-Configuration
                    Write-Host "Project name updated to $($params.PROJECT)" -ForegroundColor Green
                }
                Start-Sleep -Seconds 1
            }
            "4" {
                $newLocation = Read-Host "Enter new Azure location (e.g., southafricanorth, eastus, westeurope)"
                if (-not [string]::IsNullOrWhiteSpace($newLocation)) {
                    $params.LOCATION = $newLocation
                    Save-Configuration
                    Write-Host "Azure location updated to $($params.LOCATION)" -ForegroundColor Green
                }
                Start-Sleep -Seconds 1
            }
            "5" {
                if (Get-UserConfirmation -Message "Are you sure you want to reset to default settings?" -DefaultNo) {
                    Reset-Configuration
                    Write-Host "Settings reset to default values" -ForegroundColor Green
                }
                Start-Sleep -Seconds 1
            }
            "0" {
                # Return to main menu
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

function Load-Configuration {
    $configPath = Join-Path -Path $scriptPath -ChildPath "config.json"
    
    if (Test-Path $configPath) {
        try {
            $config = Get-Content -Path $configPath -Raw | ConvertFrom-Json
            
            $params.ENV = $config.env
            $params.LOC = $config.loc
            $params.PROJECT = $config.project
            $params.LOCATION = $config.location
            
            # Generate log file path with timestamp
            $logDir = $config.defaultLogFilePath
            if (-not (Test-Path $logDir)) {
                New-Item -ItemType Directory -Path $logDir -Force | Out-Null
            }
            $params.LogFile = Join-Path -Path $logDir -ChildPath "HomeLab_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
            
            Write-Host "Configuration loaded successfully" -ForegroundColor Green
            return $true
        }
        catch {
            Write-Host "Error loading configuration: $_" -ForegroundColor Red
            return $false
        }
    }
    else {
        Write-Host "Configuration file not found. Creating default configuration..." -ForegroundColor Yellow
        Save-Configuration
        return $true
    }
}

function Save-Configuration {
    $configPath = Join-Path -Path $scriptPath -ChildPath "config.json"
    
    $config = @{
        env = $params.ENV
        loc = $params.LOC
        project = $params.PROJECT
        location = $params.LOCATION
        defaultLogFilePath = "HomeLab_Logs"
    }
    
    try {
        $config | ConvertTo-Json | Out-File -FilePath $configPath -Force
        Write-Host "Configuration saved successfully" -ForegroundColor Green -NoConsole
        return $true
    }
    catch {
        Write-Host "Error saving configuration: $_" -ForegroundColor Red
        return $false
    }
}

function Reset-Configuration {
    $params.ENV = "dev"
    $params.LOC = "saf"
    $params.PROJECT = "homelab"
    $params.LOCATION = "southafricanorth"
    $params.LogFile = "HomeLab_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
    
    Save-Configuration
}

function Get-UserConfirmation {
    param (
        [string]$Message,
        [switch]$DefaultYes,
        [switch]$DefaultNo
    )
    
    if ($DefaultYes) {
        $prompt = "$Message (Y/n): "
        $defaultResponse = $true
    }
    elseif ($DefaultNo) {
        $prompt = "$Message (y/N): "
        $defaultResponse = $false
    }
    else {
        $prompt = "$Message (y/n): "
        $defaultResponse = $null
    }
    
    Write-Host $prompt -NoNewline -ForegroundColor Yellow
    $response = Read-Host
    
    if ([string]::IsNullOrWhiteSpace($response)) {
        return $defaultResponse
    }
    
    return $response.ToLower() -eq "y"
}

function Start-HomeLab {
    # Load configuration
    Load-Configuration
    
    # Initialize logging
    Initialize-LogFile -LogFilePath $params.LogFile
    
    # Main menu loop
    $selection = 0
    do {
        Show-MainMenu
        $selection = Read-Host "Select an option"
        
        switch ($selection) {
            "1" {
                Invoke-DeployMenu
            }
            "2" {
                Invoke-VpnCertMenu
            }
            "3" {
                Invoke-VpnGatewayMenu
            }
            "4" {
                Invoke-VpnClientMenu
            }
            "5" {
                Invoke-NatGatewayMenu
            }
            "6" {
                Invoke-DocumentationMenu
            }
            "7" {
                Invoke-SettingsMenu
            }
            "0" {
                Write-Host "Exiting Home Lab Setup..." -ForegroundColor Cyan
            }
            default {
                Write-Host "Invalid option. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }
    } while ($selection -ne "0")
}

# Start the application
Start-HomeLab
