﻿# Define the base directory - adjust this path if needed
$baseDir = "C:\Dev\home-lab-setup"

# Create base directory if it doesn't exist
if (-not (Test-Path $baseDir)) {
    New-Item -Path $baseDir -ItemType Directory -Force | Out-Null
    Write-Host "Created base directory: $baseDir" -ForegroundColor Green
}

# Define the directory structure
$directories = @(
    # Main directories
    "modules",
    "config",
    "config\templates",
    "logs",
    
    # HomeLab.Core module
    "modules\HomeLab.Core",
    "modules\HomeLab.Core\Public",
    "modules\HomeLab.Core\Private",
    
    # HomeLab.Azure module
    "modules\HomeLab.Azure",
    "modules\HomeLab.Azure\Public",
    "modules\HomeLab.Azure\Private",
    
    # HomeLab.Monitoring module
    "modules\HomeLab.Monitoring",
    "modules\HomeLab.Monitoring\Public",
    "modules\HomeLab.Monitoring\Private",
    
    # HomeLab.Security module
    "modules\HomeLab.Security",
    "modules\HomeLab.Security\Public",
    "modules\HomeLab.Security\Private"
)

# Create directories
foreach ($dir in $directories) {
    $fullPath = Join-Path -Path $baseDir -ChildPath $dir
    if (-not (Test-Path $fullPath)) {
        New-Item -Path $fullPath -ItemType Directory -Force | Out-Null
        Write-Host "Created directory: $fullPath" -ForegroundColor Green
    } else {
        Write-Host "Directory already exists: $fullPath" -ForegroundColor Yellow
    }
}

# Create module files
$moduleFiles = @{
    # HomeLab.Core module files
    "modules\HomeLab.Core\HomeLab.Core.psm1" = @'
# HomeLab.Core module
# Load all public and private function definitions

$Public = @(Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue)
$Private = @(Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue)

# Dot source the files
foreach ($import in @($Public + $Private)) {
    try {
        . $import.FullName
        Write-Verbose "Imported $($import.FullName)"
    } catch {
        Write-Error -Message "Failed to import function $($import.FullName): $_"
    }
}

# Export public functions
Export-ModuleMember -Function $Public.BaseName
'@

    "modules\HomeLab.Core\HomeLab.Core.psd1" = @'
@{
    RootModule = 'HomeLab.Core.psm1'
    ModuleVersion = '0.1.0'
    GUID = 'a1234567-e89b-12d3-a456-426614174000'
    Author = 'Jurie Smit'
    CompanyName = 'HomeLab'
    Copyright = '(c) 2025 Jurie Smit. All rights reserved.'
    Description = 'Core functionality for HomeLab setup'
    PowerShellVersion = '5.1'
    FunctionsToExport = '*' # Will be populated from Public folder
    PrivateData = @{
        PSData = @{
            Tags = @('HomeLab', 'Core')
            ReleaseNotes = 'Initial release of HomeLab.Core module'
        }
    }
}
'@

    # HomeLab.Azure module files
    "modules\HomeLab.Azure\HomeLab.Azure.psm1" = @'
# HomeLab.Azure module
# Load all public and private function definitions

$Public = @(Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue)
$Private = @(Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue)

# Dot source the files
foreach ($import in @($Public + $Private)) {
    try {
        . $import.FullName
        Write-Verbose "Imported $($import.FullName)"
    } catch {
        Write-Error -Message "Failed to import function $($import.FullName): $_"
    }
}

# Export public functions
Export-ModuleMember -Function $Public.BaseName
'@

    "modules\HomeLab.Azure\HomeLab.Azure.psd1" = @'
@{
    RootModule = 'HomeLab.Azure.psm1'
    ModuleVersion = '0.1.0'
    GUID = 'b1234567-e89b-12d3-a456-426614174000'
    Author = 'Jurie Smit'
    CompanyName = 'HomeLab'
    Copyright = '(c) 2025 Jurie Smit. All rights reserved.'
    Description = 'Azure infrastructure deployment for HomeLab'
    PowerShellVersion = '5.1'
    RequiredModules = @('HomeLab.Core') # This module depends on HomeLab.Core
    FunctionsToExport = '*' # Will be populated from Public folder
    PrivateData = @{
        PSData = @{
            Tags = @('HomeLab', 'Azure', 'Infrastructure')
            ReleaseNotes = 'Initial release of HomeLab.Azure module'
        }
    }
}
'@

    # HomeLab.Monitoring module files
    "modules\HomeLab.Monitoring\HomeLab.Monitoring.psm1" = @'
# HomeLab.Monitoring module
# Load all public and private function definitions

$Public = @(Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue)
$Private = @(Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue)

# Dot source the files
foreach ($import in @($Public + $Private)) {
    try {
        . $import.FullName
        Write-Verbose "Imported $($import.FullName)"
    } catch {
        Write-Error -Message "Failed to import function $($import.FullName): $_"
    }
}

# Export public functions
Export-ModuleMember -Function $Public.BaseName
'@

    "modules\HomeLab.Monitoring\HomeLab.Monitoring.psd1" = @'
@{
    RootModule = 'HomeLab.Monitoring.psm1'
    ModuleVersion = '0.1.0'
    GUID = 'c1234567-e89b-12d3-a456-426614174000'
    Author = 'Jurie Smit'
    CompanyName = 'HomeLab'
    Copyright = '(c) 2025 Jurie Smit. All rights reserved.'
    Description = 'Monitoring functionality for HomeLab setup'
    PowerShellVersion = '5.1'
    RequiredModules = @('HomeLab.Core') # This module depends on HomeLab.Core
    FunctionsToExport = '*' # Will be populated from Public folder
    PrivateData = @{
        PSData = @{
            Tags = @('HomeLab', 'Monitoring')
            ReleaseNotes = 'Initial release of HomeLab.Monitoring module'
        }
    }
}
'@

    # HomeLab.Security module files
    "modules\HomeLab.Security\HomeLab.Security.psm1" = @'
# HomeLab.Security module
# Load all public and private function definitions

$Public = @(Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue)
$Private = @(Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue)

# Dot source the files
foreach ($import in @($Public + $Private)) {
    try {
        . $import.FullName
        Write-Verbose "Imported $($import.FullName)"
    } catch {
        Write-Error -Message "Failed to import function $($import.FullName): $_"
    }
}

# Export public functions
Export-ModuleMember -Function $Public.BaseName
'@

    "modules\HomeLab.Security\HomeLab.Security.psd1" = @'
@{
    RootModule = 'HomeLab.Security.psm1'
    ModuleVersion = '0.1.0'
    GUID = 'd1234567-e89b-12d3-a456-426614174000'
    Author = 'Jurie Smit'
    CompanyName = 'HomeLab'
    Copyright = '(c) 2025 Jurie Smit. All rights reserved.'
    Description = 'Security functionality for HomeLab setup'
    PowerShellVersion = '5.1'
    RequiredModules = @('HomeLab.Core') # This module depends on HomeLab.Core
    FunctionsToExport = '*' # Will be populated from Public folder
    PrivateData = @{
        PSData = @{
            Tags = @('HomeLab', 'Security')
            ReleaseNotes = 'Initial release of HomeLab.Security module'
        }
    }
}
'@

    # Main script file
    "home-lab-setup.ps1" = @'
<#
.SYNOPSIS
    Home Lab Setup - Main Entry Point
.DESCRIPTION
    This script serves as the main entry point for the Home Lab Setup project,
    providing a menu-driven interface to access all functionality.
.NOTES
    Author: Jurie Smit
    Date: March 5, 2025
#>

# Get script path
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$modulesPath = Join-Path -Path $scriptPath -ChildPath "modules"

# Import modules
$modulesToImport = @(
    "HomeLab.Core",
    "HomeLab.Azure"
)

foreach ($module in $modulesToImport) {
    $modulePath = Join-Path -Path $modulesPath -ChildPath $module
    if (Test-Path $modulePath) {
        Import-Module $modulePath -Force
        Write-Host "Imported module: $module" -ForegroundColor Green
    } else {
        Write-Host "Module not found: $module" -ForegroundColor Red
        exit 1
    }
}

# Check prerequisites
if (-not (Test-Prerequisites)) {
    Write-Host "Installing missing prerequisites..." -ForegroundColor Yellow
    Install-Prerequisites
    
    if (-not (Test-Prerequisites)) {
        Write-Host "Prerequisites installation failed. Please check the logs and try again." -ForegroundColor Red
        exit 1
    }
}

# Run first-time setup if needed
if (-not (Test-SetupComplete)) {
    Write-Host "Running first-time setup..." -ForegroundColor Yellow
    Initialize-HomeLab
}

# Main menu loop
$exitRequested = $false
while (-not $exitRequested) {
    $menuItems = @{
        "1" = "Deployment"
        "2" = "Configuration"
        "3" = "Monitoring"
    }
    
    $selection = Show-Menu -Title "HOMELAB SETUP - MAIN MENU" -MenuItems $menuItems
    
    switch ($selection) {
        "1" {
            # Deployment menu
            $deployMenuItems = @{
                "1" = "Deploy All Components"
                "2" = "Deploy Network Only"
                "3" = "Deploy VPN Gateway Only"
                "4" = "Deploy NAT Gateway Only"
                "5" = "Check Deployment Status"
            }
            
            $deploySelection = Show-Menu -Title "DEPLOYMENT MENU" -MenuItems $deployMenuItems
            
            $config = Get-Configuration
            
            switch ($deploySelection) {
                "1" {
                    Write-Host "Starting full deployment..." -ForegroundColor Cyan
                    Deploy-Infrastructure
                }
                "2" {
                    Write-Host "Deploying network only..." -ForegroundColor Cyan
                    Deploy-Infrastructure -ComponentsOnly "network"
                }
                "3" {
                    Write-Host "Deploying VPN Gateway only..." -ForegroundColor Cyan
                    Deploy-Infrastructure -ComponentsOnly "vpngateway"
                }
                "4" {
                    Write-Host "Deploying NAT Gateway only..." -ForegroundColor Cyan
                    Deploy-Infrastructure -ComponentsOnly "natgateway"
                }
                "5" {
                    Write-Host "Checking deployment status..." -ForegroundColor Cyan
                    $config = Get-Configuration
                    $resourceGroup = "$($config.ENV)-$($config.LOC)-rg-$($config.PROJECT)"
                    az group show --name $resourceGroup --query "properties.provisioningState" -o tsv
                }
                "0" {
                    # Return to main menu
                }
            }
        }
        "2" {
            # Configuration menu - implement later
            Write-Host "Configuration menu not implemented yet." -ForegroundColor Yellow
        }
        "3" {
            # Monitoring menu - implement later
            Write-Host "Monitoring menu not implemented yet." -ForegroundColor Yellow
        }
        "0" {
            $exitRequested = $true
            Write-Host "Exiting HomeLab Setup..." -ForegroundColor Yellow
        }
        default {
            Write-Host "Invalid option. Please try again." -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }
    
    # Pause after each action unless exiting
    if (-not $exitRequested -and $selection -ne "0") {
        Write-Host "Press any key to continue..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}
'@
}

# Create module files
foreach ($file in $moduleFiles.Keys) {
    $fullPath = Join-Path -Path $baseDir -ChildPath $file
    if (-not (Test-Path $fullPath)) {
        $moduleFiles[$file] | Out-File -FilePath $fullPath -Encoding utf8 -Force
        Write-Host "Created file: $fullPath" -ForegroundColor Green
    } else {
        Write-Host "File already exists: $fullPath" -ForegroundColor Yellow
    }
}

# Create core function files
$coreFunctions = @{
    "modules\HomeLab.Core\Public\Write-Log.ps1" = @'
<#
.SYNOPSIS
    Writes a log message to the console and optionally to a log file
.DESCRIPTION
    Writes a formatted log message with timestamp and log level to the console
    with appropriate color coding, and optionally to a log file.
.PARAMETER Message
    The message to log
.PARAMETER Level
    The log level (Info, Warning, Error, Success)
.PARAMETER LogFile
    Optional path to a log file
.EXAMPLE
    Write-Log -Message "Operation completed" -Level Success -LogFile "C:\Logs\homelab.log"
#>
function Write-Log {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet('Info', 'Warning', 'Error', 'Success')]
        [string]$Level = 'Info',
        
        [Parameter(Mandatory = $false)]
        [string]$LogFile
    )
    
    # Define colors for different log levels
    $colors = @{
        'Info' = 'White'
        'Warning' = 'Yellow'
        'Error' = 'Red'
        'Success' = 'Green'
    }
    
    # Format timestamp
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    
    # Write to console with appropriate color
    Write-Host $logMessage -ForegroundColor $colors[$Level]
    
    # Write to log file if specified
    if ($LogFile) {
        # Create directory if it doesn't exist
        $logDir = Split-Path -Parent $LogFile
        if (-not (Test-Path $logDir)) {
            New-Item -Path $logDir -ItemType Directory -Force | Out-Null
        }
        
        $logMessage | Out-File -FilePath $LogFile -Append
    }
}
'@

    "modules\HomeLab.Core\Public\Get-Configuration.ps1" = @'
<#
.SYNOPSIS
    Gets the configuration for the HomeLab setup
.DESCRIPTION
    Reads the configuration from the config file or creates a default configuration
    if the file doesn't exist.
.PARAMETER ConfigFile
    Path to the configuration file
.EXAMPLE
    $config = Get-Configuration
.EXAMPLE
    $config = Get-Configuration -ConfigFile "C:\Config\homelab.json"
#>
function Get-Configuration {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [string]$ConfigFile = "$env:USERPROFILE\.homelab\config.json"
    )
    
    # Check if config file exists
    if (-not (Test-Path $ConfigFile)) {
        Write-Log -Message "Configuration file not found at $ConfigFile" -Level Warning
        
        # Create default config
        $defaultConfig = @{
            ENV = "dev"
            LOC = "we"
            PROJECT = "homelab"
            LOCATION = "westeurope"
            LogFile = "$(Get-Location)\logs\homelab_$(Get-Date -Format 'yyyyMMdd').log"
            LastUpdated = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
        
        # Create directory if it doesn't exist
        $configDir = Split-Path -Parent $ConfigFile
        if (-not (Test-Path $configDir)) {
            New-Item -Path $configDir -ItemType Directory -Force | Out-Null
        }
        
        # Save default config
        $defaultConfig | ConvertTo-Json | Out-File -FilePath $ConfigFile -Force
        Write-Log -Message "Created default configuration file at $ConfigFile" -Level Info
        
        return $defaultConfig
    }
    
    # Read and return config
    try {
        $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        return $config
    }
    catch {
        Write-Log -Message "Error reading configuration file: $_" -Level Error
        throw "Failed to read configuration file: $_"
    }
}
'@

    "modules\HomeLab.Core\Public\Set-Configuration.ps1" = @'
<#
.SYNOPSIS
    Updates the configuration for the HomeLab setup
.DESCRIPTION
    Updates the configuration with the provided values and saves it to the config file
.PARAMETER ConfigData
    A hashtable containing the configuration values to update
.PARAMETER ConfigFile
    Path to the configuration file
.EXAMPLE
    Set-Configuration -ConfigData @{ ENV = "prod"; LOC = "we" }
.EXAMPLE
    Set-Configuration -ConfigData @{ ENV = "prod"; LOC = "we" } -ConfigFile "C:\Config\homelab.json"
#>
function Set-Configuration {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [hashtable]$ConfigData,
        
        [Parameter(Mandatory = $false)]
        [string]$ConfigFile = "$env:USERPROFILE\.homelab\config.json"
    )
    
    # Get current config
    try {
        if (Test-Path $ConfigFile) {
            $currentConfig = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
            $configObj = [PSCustomObject]$currentConfig
        }
        else {
            $configObj = [PSCustomObject]@{}
        }
        
        # Update config with new values
        foreach ($key in $ConfigData.Keys) {
            $configObj | Add-Member -MemberType NoteProperty -Name $key -Value $ConfigData[$key] -Force
        }
        
        # Add last updated timestamp
        $configObj | Add-Member -MemberType NoteProperty -Name "LastUpdated" -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -Force
        
        # Create directory if it doesn't exist
        $configDir = Split-Path -Parent $ConfigFile
        if (-not (Test-Path $configDir)) {
            New-Item -Path $configDir -ItemType Directory -Force | Out-Null
        }
        
        # Save updated config
        $configObj | ConvertTo-Json | Out-File -FilePath $ConfigFile -Force
        Write-Log -Message "Configuration updated successfully" -Level Success
        
        return $true
    }
    catch {
        Write-Log -Message "Error updating configuration: $_" -Level Error
        return $false
    }
}
'@

    "modules\HomeLab.Core\Public\Show-Menu.ps1" = @'
<#
.SYNOPSIS
    Displays a menu and returns the user's selection
.DESCRIPTION
    Displays a formatted menu with the provided title and menu items,
    and returns the user's selection.
.PARAMETER Title
    The title of the menu
.PARAMETER MenuItems
    A hashtable containing the menu items, where the key is the menu item number
    and the value is the menu item text
.PARAMETER ExitOption
    The option number for exiting the menu
.EXAMPLE
    $menuItems = @{
        "1" = "Option 1"
        "2" = "Option 2"
    }
    $selection = Show-Menu -Title "Main Menu" -MenuItems $menuItems
#>
function Show-Menu {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Title,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$MenuItems,
        
        [Parameter(Mandatory = $false)]
        [string]$ExitOption = "0"
    )
    
    Clear-Host
    
    # Display title
    $titleBar = "═" * ($Title.Length + 10)
    Write-Host "╔$titleBar╗" -ForegroundColor Blue
    Write-Host "║    $Title    ║" -ForegroundColor Blue
    Write-Host "╚$titleBar╝" -ForegroundColor Blue
    Write-Host ""
    
    # Display menu items
    foreach ($key in $MenuItems.Keys | Sort-Object) {
        Write-Host "$key. $($MenuItems[$key])" -ForegroundColor Green
    }
    
    # Display exit option
    Write-Host ""
    Write-Host "$ExitOption. Exit" -ForegroundColor Yellow
    Write-Host ""
    
    # Get user selection
    $selection = Read-Host "Select an option"
    
    return $selection
}
'@

    "modules\HomeLab.Core\Public\Test-Prerequisites.ps1" = @'
<#
.SYNOPSIS
    Tests if the prerequisites for the HomeLab setup are installed
.DESCRIPTION
    Checks if the required tools (Azure CLI, Az PowerShell module) are installed
.EXAMPLE
    if (-not (Test-Prerequisites)) {
        Install-Prerequisites
    }
#>
function Test-Prerequisites {
    [CmdletBinding()]
    param()
    
    Write-Log -Message "Checking prerequisites..." -Level Info
    
    # Check if Azure CLI is installed
    $azCliInstalled = $null -ne (Get-Command az -ErrorAction SilentlyContinue)
    if (-not $azCliInstalled) {
        Write-Log -Message "Azure CLI is not installed" -Level Warning
        return $false
    }
    
    # Check if Az PowerShell module is installed
    $azPowerShellInstalled = $null -ne (Get-Module -ListAvailable Az.Accounts)
    if (-not $azPowerShellInstalled) {
        Write-Log -Message "Az PowerShell module is not installed" -Level Warning
        return $false
    }
    
    Write-Log -Message "All prerequisites are installed" -Level Success
    return $true
}
'@

    "modules\HomeLab.Core\Public\Install-Prerequisites.ps1" = @'
<#
.SYNOPSIS
    Installs the prerequisites for the HomeLab setup
.DESCRIPTION
    Installs the required tools (Azure CLI, Az PowerShell module)
.EXAMPLE
    Install-Prerequisites
#>
function Install-Prerequisites {
    [CmdletBinding()]
    param()
    
    Write-Log -Message "Installing prerequisites..." -Level Info
    
    # Install Azure CLI if not installed
    if ($null -eq (Get-Command az -ErrorAction SilentlyContinue)) {
        Write-Log -Message "Installing Azure CLI..." -Level Info
        
        try {
            Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi
            Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'
            Remove-Item .\AzureCLI.msi -Force
            
            # Refresh PATH
            $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
            
            Write-Log -Message "Azure CLI installed successfully" -Level Success
        }
        catch {
            Write-Log -Message "Failed to install Azure CLI: $_" -Level Error
            return $false
        }
    }
    
    # Install Az PowerShell module if not installed
    if ($null -eq (Get-Module -ListAvailable Az.Accounts)) {
        Write-Log -Message "Installing Az PowerShell module..." -Level Info
        
        try {
            Install-Module -Name Az -AllowClobber -Scope CurrentUser -Force
            Write-Log -Message "Az PowerShell module installed successfully" -Level Success
        }
        catch {
            Write-Log -Message "Failed to install Az PowerShell module: $_" -Level Error
            return $false
        }
    }
    
    Write-Log -Message "All prerequisites installed successfully" -Level Success
    return $true
}
'@

    "modules\HomeLab.Core\Public\Test-SetupComplete.ps1" = @'
<#
.SYNOPSIS
    Tests if the HomeLab setup has been completed
.DESCRIPTION
    Checks if the configuration file exists
.EXAMPLE
    if (-not (Test-SetupComplete)) {
        Initialize-HomeLab
    }
#>
function Test-SetupComplete {
    [CmdletBinding()]
    param()
    
    $configFile = "$env:USERPROFILE\.homelab\config.json"
    $result = Test-Path $configFile
    
    if ($result) {
        Write-Log -Message "HomeLab setup is complete" -Level Info
    } else {
        Write-Log -Message "HomeLab setup is not complete" -Level Info
    }
    
    return $result
}
'@

    "modules\HomeLab.Core\Public\Initialize-HomeLab.ps1" = @'
<#
.SYNOPSIS
    Initializes the HomeLab setup
.DESCRIPTION
    Creates the configuration file and sets up the initial configuration
.EXAMPLE
    Initialize-HomeLab
#>
function Initialize-HomeLab {
    [CmdletBinding()]
    param()
    
    Write-Log -Message "Initializing HomeLab setup..." -Level Info
    
    # Create config directory
    $configDir = "$env:USERPROFILE\.homelab"
    if (-not (Test-Path $configDir)) {
        New-Item -Path $configDir -ItemType Directory -Force | Out-Null
        Write-Log -Message "Created configuration directory: $configDir" -Level Info
    }
    
    # Create default config
    $configFile = "$configDir\config.json"
    $defaultConfig = @{
        ENV = "dev"
        LOC = "we"
        PROJECT = "homelab"
        LOCATION = "westeurope"
        LogFile = "$(Get-Location)\logs\homelab_$(Get-Date -Format 'yyyyMMdd').log"
        LastSetup = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    }
    
    $defaultConfig | ConvertTo-Json | Out-File -FilePath $configFile -Force
    Write-Log -Message "Created default configuration file: $configFile" -Level Info
    
    # Create logs directory
    $logsDir = "$(Get-Location)\logs"
    if (-not (Test-Path $logsDir)) {
        New-Item -Path $logsDir -ItemType Directory -Force | Out-Null
        Write-Log -Message "Created logs directory: $logsDir" -Level Info
    }
    
    Write-Log -Message "HomeLab setup initialized successfully" -Level Success
    return $true
}
'@
}

# Create core function files
foreach ($file in $coreFunctions.Keys) {
    $fullPath = Join-Path -Path $baseDir -ChildPath $file
    if (-not (Test-Path $fullPath)) {
        $coreFunctions[$file] | Out-File -FilePath $fullPath -Encoding utf8 -Force
        Write-Host "Created file: $fullPath" -ForegroundColor Green
    } else {
        Write-Host "File already exists: $fullPath" -ForegroundColor Yellow
    }
}
